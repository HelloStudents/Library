jQuery(window).load(function(){

	'use strict';

	// Theme Panel Open/Close
	jQuery( "#theme_panel #theme_panel_button" ).click(function(){
		jQuery( "#theme_panel" ).toggleClass( "close_panel", "open_panel" );
		jQuery( "#theme_panel" ).toggleClass( "open_panel", "close_panel" );
		return false;
	});

	// Color Skins
//	jQuery('.color_link').click(function(){
//		var title = jQuery(this).attr('title');		
//		jQuery('#changeable_color').attr('href', 'css/colors/' + title + '.css');				
//	  	return false;
//    });	
    
    jQuery(".color_link").click(function() {
    	//jQuery("link[data-id=5]").attr("href","schemes.php?color="+jQuery(this).attr('data-color'));
    	//jQuery("link#dynamic-demo-css-css").attr("href","dynamic-css.php?scheme="+jQuery(this).attr('data-color'));
    	jQuery("link#dynamic-demo-css-css").attr("href","css/dynamic-css.php?scheme="+jQuery(this).attr('data-color'));
    	return false;
    });
    
    // Header Style
    jQuery('#switch-header').on('change', function(){

    	jQuery('#pageloader').fadeIn(150, function(){	
    		jQuery("#pageloader .spinner").fadeIn(200);
    		document.location.href = "http://veented.com/themes/waxom/"+jQuery('#switch-header').val()+"?header_style="+jQuery('#switch-header').val();
    	});
    	//jQuery('header').addClass('dark-nav').removeClass('white-nav');
    	//jQuery('img.site_logo').attr('src', 'images/logo' + '.png');				
    });	


    // Color Skins
	jQuery('#black_menu').click(function(){
		jQuery('header').addClass('dark-nav').removeClass('white-nav');
		jQuery('img.site_logo').attr('src', 'images/logo' + '.png');				
    });	

    // Color Skins
	jQuery('#white_menu').click(function(){
		jQuery('header').addClass('white-nav').removeClass('dark-nav');	
		jQuery('img.site_logo').attr('src', 'images/logo-dark' + '.png');		
    });	


    // Normal Nav - For only Fulscreen Versions
	jQuery('#nav_normal').click(function(){
		jQuery('#navigation').removeClass('nav-from-top');			
    });	

    // Nav From Top - For only Fulscreen Versions
	jQuery('#nav_from_top').click(function(){
		jQuery('#navigation').addClass('nav-from-top');			
    });


    // Nav From Top - For only Fulscreen Versions
	jQuery('.layout_tone').click(function(){
		var title = jQuery(this).attr('title');		
		jQuery('#changeable_tone').attr('href', 'css/' + title + '.css');				
	  	return false;	
    });

});