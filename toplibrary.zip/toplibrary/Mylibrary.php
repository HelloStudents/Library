<?php
session_start();
$status="Create  Account"; 
$msg="";
$PaymentID="";
$PaymentDate="";
$CardNo="";
$CardType="";

$Email="";
$Password="";
$amsg="";

	include("advance_control.php");

   if(isset($_REQUEST['msg']))
   {
	  $msg=$_REQUEST['msg'];
   
   }
   if(!isset($_SESSION["stillnew"])&&!isset($_SESSION["member"]))
   {
	// header("location:Member.php?msg=Need to make registration first !");
   
   }
  
  

   $MemberID= getID("member","MemberID","CT-",6,"CT-000001");
  // echo "sds".$id;

   
   if(isset($_REQUEST['rid']))
   {
	   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $mysqli = new mysqli('localhost','root','','top');

	// if ($mysqli->connect_error) {
		//die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		//}
	  

	 
				 $sql="UPDATE borrowdetail SET Status='return' WHERE BorrowID='".$_REQUEST['rid']."'";
    process($sql);
	
	//total book qty
	 $result = $mysqli->query("SELECT * FROM book WHERE BookID ='".$_REQUEST['bid']."'");
		//row_data= $result->
		$row=$result->fetch_assoc();
	
		$total=	$row["NumberofCopies"]+1;
	//	$_SESSION['memberinfo']=array($row["MemberName"],$row["Email"],$row["Address"],$row["Phone"],$row["MemberExpiredDate"]);
	

		
	
	$sql="UPDATE book SET NumberofCopies='$total' WHERE BookID='".$_REQUEST['bid']."'";
    process($sql);
unset($_SESSION["stillnew"]);
unset($_SESSION["stillnewinfo"]);
				header("Location: Mylibrary.php");
			
		$mysqli->close();
	  	 }
		
 


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>

<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <div class="menu_place">
    	<div class="menu">
           <?php include("menudata.php"); ?>
        </div>
    </div>
    	<div class="l_content"  style="width:350px;">
        	
            <?php
			if(isset($_SESSION["memberinfo"]))
			{
				
			    $tmp=$_SESSION["memberinfo"];
				echo "<table   style=\"margin-left:20px;border:#666 thin solid;padding:20px;margin-top:20px;\" cellpadding=5px>";
				echo "<tr><td colspan=2 align=center>Member Information<hr class=palblue_hr /></td></tr>";
					echo "<tr style=\"border-bottom:#666 thin solid;\" >";
						echo "<td>Member Name</td><td>:". $tmp[0]."</td>";
					echo "</tr>";
					echo "<tr  style=\"border-bottom:#666 thin solid;\" >";
						echo "<td> Address</td><td>:". $tmp[2]."</td>";
					echo "</tr>";
					echo "<tr style=\"border-bottom:#666 thin solid;\" >";
						echo "<td> Email</td><td>:". $tmp[1]."</td>";
					echo "</tr>";
					echo "<tr style=\"border-bottom:#666 thin solid;\" >";
						echo "<td>Expire Date</td><td>:". $tmp[4]."</td>";
					echo "</tr>";
					echo "<tr style=\"border-bottom:#666 thin solid;\" >";
						echo "<td>Total Points</td><td>:". $tmp[5]."</td>";
					echo "</tr>";
				echo "</table>";
				
			   
			}
			
			
			?>
            <a href="MemberRenew.php?ex=<?php echo base64_encode($tmp[4]); ?>" style="margin-left:20px;text-align:center;color:#000;text-decoration:none;margin:0 auto;margin-top:20px; height:40px;line-height:40px;background-color:#990;display:block;padding-left:10px;padding-right:10px;width:180px;">Member Renew</a>
            
             <a href="PointPurchase.php" style="margin-left:20px;text-align:center;color:#000;text-decoration:none;margin:0 auto;margin-top:20px; height:40px;line-height:40px;background-color:#990;display:block;padding-left:10px;padding-right:10px;width:180px;">Buy Point</a>
          
        </div>
        <div class="r_content"  style="width:650px;padding-top:20px; ">
        <?php echo $msg;?>
           <h3 align="center">Borrow Books</h3>
           <hr class="palred_hr"/>
           <?php
		   $query="SELECT DISTINCT bk.BookID ,bk.BookName,bd.BorrowDate,bd.ReturnDate ,bk.Image,bk.filepath ,b.BorrowID FROM borrow AS b,member AS m ,borrowdetail AS bd ,book as bk WHERE b.MemberID=m.MemberID AND b.BorrowID=bd.BorrowID  AND  bd.BookID=bk.BookID AND bd.Status='borrow' AND b.MemberID='".$_SESSION["member"]."'";
		//   echo $query;
		   $mysqli=connect();
						 $result=$mysqli->query($query);
						 $rowcount=mysqli_num_rows( $result);
						 $row=0;
						 if($rowcount>0)
						{
						
					
						 
						
						 
						 while($row=$result->fetch_array(MYSQLI_NUM))
						 {
							
							echo "<div id=additem style=width:550px >";
						    echo "<table>";
						  echo "<tr><td><a href=Readbook.php?path=".$row[5]." target=_blank><img src=".$row[4]." width=150px height=120px  /></a></td>";
						  echo "<td valign=top>";
						  echo "<table>";
						  echo "<tr><td><span class=name  >".$row[1]."</span></td></tr>";
						    echo "<tr><td>Return on <br/><span class=name  >".$row[1]."</span></td></tr>";
					
					echo	 "<tr><td><a href=Mylibrary.php?rid=".$row[6]."&bid=".$row[0]." style=padding-left:0px;margin-left:0px;color:#666600;border:#666600 thin solid;width:100px; >Return Now</a></td></tr>";
					echo "</table></td></tr></table>";
						   echo "</div>";
						   $row++;
						 }
						}
						else
						{
						 echo "<span style=color:#999;font-size:16px;margin-top:20px;margin-bottom:10px; >There is no data related with search keywords  !</span>";
						}
		   ?>
        </div>
        <div style="clear:left;height:20px;"></div>
           <?php include("footer.php"); ?>
</body>
</html>
