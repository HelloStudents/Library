<?php
session_start();
$status="Save"; 
$msg="";
$SupplierID="";
$SupplierName="";
$Address="";
$Phone="";
$Email="";
$Fax="";


	include("advance_control.php");
	$productid=getID("product","productid","p-",6,"p-000001");
	$total=0;
      if(isset($_SESSION['sitem']))
	  {
		
	     for($z=0;$z<count( $_SESSION['sitem']);$z++)
		 { 
		 $total=$total+($_SESSION['sitem'][$z][2]*$_SESSION['sitem'][$z][3]);
		 }
	  }
 if(isset($_REQUEST['m']))
   {
	  $msg=$_REQUEST['m'];
   
   }

   if(isset($_REQUEST['btn']))
   {
	   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $mysqli = new mysqli('localhost','root','','royal');

	// if ($mysqli->connect_error) {
		//die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		//}
	   if($_REQUEST['btn']=="Save")
	   {
$destination="";
			
				   if($_FILES['file']['name']!="")
				   {
					  $newImage=$_FILES['file']['name'];                    
			
					  $destination="product/".$newImage;
					  $action=copy( $_FILES['file']['tmp_name'],$destination );
			
				   }
				//   echo $_POST['ItemID'],$_POST['Itemname'],$_POST['Qty'],$_POST['Price'],"0",$_POST['Description'],$_POST['itype'],$destination;
		
				
				$productid=getID("product","productid","p-",6,"p-000001");
$data=array($productid,$_POST['designid'],$_POST['productname'],$_POST['description'],$_POST['price'],$total,"",$_POST['qty'],"",$destination);

saveData($data,"product");


		 for($z=0;$z<count( $_SESSION['sitem']);$z++)
		 {

		     //$data=array($bid ,$_SESSION['sitem'][$z][0],$_SESSION['sitem'][$z][2],$_SESSION['sitem'][$z][3]);
	
	 $data=array($_SESSION['sitem'][$z][0],$productid,$_SESSION['sitem'][$z][2],"inhouse");
		
			saveData($data,"productdetail");
			 
	  
		 }
				
			unset($_SESSION['sitem']);
		 header("location:ProductList.php?msg=Successfully Save !");
			
		
	  	 }
		 else
		 {
		 }
 
       }


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />
<script type="text/javascript" src="jquery-1.9.1.js"></script>

<script type="text/javascript">
$(document).ready(function(e) 
 {
	
     $('#itemid').change(function()
      {
		 
		     var type=$(this).val();
			// var area=$('#farea');
			
			
			   $.ajax({
			      
			   type: 'POST',
			   url: 'purchaseitem.php',
			   data: 'type='+type,
			   success: function(msg){
				
				 var d=msg.split("&");
				 $('#ItemID').val(d[0]);
		  		 $('#itmname').val(d[1]);
				 	  $('#sqty').html("Current yard:"+d[2]+" , Current Selling Price:"+d[3]+" , Product Type :"+d[4]);
			
				
			   }
			   
			   });
			  }); 
			  	 $('#btnadd').click(function()
            {
				if($('#ItemID').val()=="")
				{
				    alert("Please Click on the item");
				}
				else if($('#Qty').val()==""||$('#Qty').val()<1)
				{
				    alert("Please Enter valid Qty(Order Qty must be at least 1!)");
				}
				else if($('#Price').val()==""||($('#Price').val()<500))
				{
				 		    alert("Please Enter valid Price(Price  must be at least 500!)");
				}
				else
				{
				  
				  //alert("d");
				  $.ajax({
			      
			   type: 'POST',
			   url: 'purchaseitem.php',
			   data: 'ItemID='+$('#ItemID').val()+"&act=add&qty="+$('#Qty').val()+"&bbtype="+ $('#ItemID').val()+"&price="+$('#Price').val()+"&salerate="+$('#salerate').val(),
			   success: function(msg){
				
				$('#bitmarea').html(msg);
				
				
			      }
				  });
				    $.ajax({
			      
			   type: 'POST',
			   url: 'purchaseitem.php',
			   data:"testact=total",
			   success: function(gg){
				
				$('#total').val(gg);
				
			      }
				  });
				}
			});
 });
</script>
</head>

<body>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <div class="menu_place">
    	<div class="menu">
     <?php include("menudata.php"); ?>
        </div>
    </div>
    	<div class="l_content">
        	<ul id="sidemenu">
            	<li class="smtitle ">Entry</li>
        <li>  <a href="StaffList.php"  >Staff </a></li>
          <li> <a href="Designlist.php" class="act" >Design List </a></li>
         <li>  <a href="Rawmateriallist.php"  >Raw Material List </a></li>
            	
            </ul>
        </div>
        <div class="r_content" >
            <form action="Product.php" method="post" enctype="multipart/form-data">
            
            <table class="tform"  style="margin-left:30px;">
                <tr>
                    <td colspan="2"><h3>Product Registration</h3><hr class="palblue_hr"/> </td>
                </tr>
                
                            <tr>
                                <td >Product ID</td><td><input name="productid" type="text" value="<?php echo $productid;?>" readonly="readonly" /></td>
                            </tr>
                             
                            <tr>
                                <td >Product Name</td><td><input type="text" name="productname" value="<?php echo $SupplierName; ?>" /></td>
                            </tr>
                            <tr>
                                <td valign="top">Description</td><td><textarea cols="20" rows="5" name="description"  ><?php echo $Address; ?></textarea></td>
                            </tr>
                            
                             
                           
                             <tr>
                                <td >Design</td><td><?php fillToCombowithtitle("design",1,"designid","Choose Design")?></td>
                            </tr>
                             <tr>
                                <td >Qty</td><td><input type="text" name="qty" value="0" /></td>
                            </tr>
                             <tr>
                                <td >Price</td><td><input type="text" name="price" value="0" /></td>
                            </tr>
                           
                     <tr>
                                <td colspan="2">
                               	 <div id="farea" >
     
   					 </div>
                                </td>
                            </tr>
                             <tr>
             <td>Image</td> <td>     <input type="file" name="file"  	 class="green" style="width:200px;"/></td>
              
             </tr>
              <tr>
                                <td ></td><td><input type="submit" name="btn" value="<?php  echo $status;?>" /></td>
                            </tr>
            
             <tr>
             	<td colspan="2">
                
             </tr>
              
                             <tr>
                                <td colspan="2"><hr class="palblue_hr"/>  </td>
                            </tr>
            </table>
              </form>
           <table class="tform" >
                <tr>
                <td>
                	   <?php
                                      	echo "<div id=tt>";    	
											  printCombowithscript("SELECT * FROM rawmaterial","name=materialid  id=itemid " ,"materialname","materialid");
											echo "</div >";
										  ?>
                
                 </td>
                 <td>
                 <table>
                                                         <tr>
                                                           <td colspan="3"><h3>Raw material Information</h3>
                                                             <hr/></td>
                                                         </tr>
                                                         <tr>
                                                         <td>Raw ID</td> <td><input name="ItemID" type="text" class="green" id="ItemID" value="" readonly="readonly" /></td>
                                                          
                                                         </tr>
                                                          <tr>
                                                         <td>Raw Name</td> <td><input name="Itemname" type="text" class="green" id="itmname" readonly="readonly"  /></td>
                                                          
                                                         </tr>
                                                          <tr>
                                                         <td>Description</td> <td><textarea id="sqty" name="sqty" ></textarea></td>
                                                          
                                                         </tr>
                                                         
                                                          <tr>
                                                         <td>Yard</td> <td><input type="text" id="Qty" name="Qty"  /></td>
                                                          
                                                         </tr>
                                                          <tr>
                                                         <td>Price</td> <td><input type="text" id="Price"  name="Price"  /></td>

                                                          
                                                         </tr>
                                                         <tr>
                                                           <td colspan="2" align="right"><input type="submit" class="buton" name="btnaddd" id="btnadd" value="Add Product" />                  <hr/>
                                                           
                                                            </td>
                                                         </tr>
                                                         
                                                      </table>
                 </td>
                 
                 </tr>
                 <tr>
                 	<td colspan="2"><div id="bitmarea">
                                        
                                        <?php
										
										if(isset($_SESSION['sitem']))
	  {
		  $t=count($_SESSION['sitem']);
	      
	    echo "<table border=1>
	      <th>Item ID</th><th>Item Name</th><th>Qty</th><th>Price</th>";
	     for($z=0;$z<count( $_SESSION['sitem']);$z++)
		 {
		   
		  echo "<tr>
		  	<td>". $_SESSION['sitem'][$z][0]."</td>
			 	<td>". $_SESSION['sitem'][$z][1]."</td>
				 	<td>". $_SESSION['sitem'][$z][2]."</td>
					<td>". $_SESSION['sitem'][$z][3]."</td>
		  </tr>";
	  
		 }
		    echo "</table>";
		
	  }
										
										?>
                                        
                                        </div></td>
                 </tr>
                 </table>
        </div>
        <div style="clear:left;height:20px;"></div>
        <div class="menu_place">
    	<div class="menu">
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT ( C ) 2016 | ROYAL KANOK </span>
                </div>
                	<div style="width:50%;float:right;">
                     	<a href="" style="float:right;">Admin Area</a>
                </div>
        </div>
    </div>  
    </div>
  
</div>
</body>
</html>
