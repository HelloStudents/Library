<?php
session_start();
include("advance_control.php");


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="jquery.datepick.js"></script>
<script type="text/javascript">
$(function() {
	$('#popupDatepicker').datepick();
$('#popupDatepicker1').datepick();
});
</script>
    <style type="text/css">
@import "flora.datepick.css";
</style>
    
</head>
<body>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <hr class="palblue_hr" />
    	
        <div class="" >
           <?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg'];
				 }
				?>
  <table width="100%" align="center">
  <tr>
  	<td colspan="2">
 
    </td>
  </tr>
  <tr>
    <td valign="top">
   
     
          <?php

  
$column=$_SESSION['column'];
$column_name=$_SESSION['column_name'];		
$query=$_SESSION['sql_result'];
		 
		 if(isset($_SESSION['sql_result']))
		 {
			 echo "<table align=center><tr><td align=center ><h3>".$_SESSION['status']."</h3></td></tr>";
			 echo "<tr><td>";
		printTable($query,count($column),$column,$column_name);

		  
		  echo "</td></tr></table>";
		 }
	
	
	


?>
     </td>
  </tr>
  
  <table>
<tr>
<td>
</td>
</tr>
</table>
    
        </div>
        <div style="clear:left;height:20px;"></div>
    </div>
    
</div>
</body>

</html>
