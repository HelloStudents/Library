<?php
session_start();



 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>

        <?php
		 if(isset($_REQUEST['path']))
		 { 
  $file =$_REQUEST['path'];
  $filename = explode("/",$_REQUEST['path']);
  header('Content-type: application/pdf');
  header('Content-Disposition: inline; filename="' . $filename[1] . '"');
  header('Content-Transfer-Encoding: binary');
  header('Accept-Ranges: bytes');
  @readfile($file);
		 }
?>
</body>
</html>
