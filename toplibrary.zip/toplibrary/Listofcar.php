<?php
session_start();


	include("advance_control.php");
	

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>
<div class="container">
	<div class="menu_place">
    	<div class="menu">
        <?php include("menudata.php"); ?>

     
        </div>
    </div>
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <hr class="palblue_hr" />
    	<div class="l_content">
        	<ul id="sidemenu">
            	<li class="smtitle ">Category</li>
          
              <?php include("sidemenu.php"); ?>
           
            </ul>
        </div>
        <div class="r_content" >
            <form action="uproduct.php" enctype="multipart/form-data" method="post"/>
            <table width="100%" style="margin-top:20px;">
            	<tr>
                	<td  width="30%">Please type product Name</td><td><input type="text" name="tsearch"  style="width:100%"/></td>
                    <td width="20%"><input type="submit"  name="search" value="Search"/></td>
                </tr>
            </table>
<?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg']."<br/>";
				 }
				?>
              
     <?php
              		
					  $query="SELECT * from product";
					  if(isset($_REQUEST["catid"]))
					  {
						 
					    $query="SELECT * from product WHERE categoryID='".$_REQUEST["catid"]."'";
					  }
					  if(isset($_REQUEST["search"]))
					  {
						 
					    $query="SELECT * from product WHERE productname LIKE '%".$_REQUEST["tsearch"]."%'";
					  }
					  
					$mysqli=connect();
						 $result=$mysqli->query($query);
						 $rowcount=mysqli_num_rows( $result);
						 $row=0;
						 if($rowcount>0)
						{
						
					
						 
						
						 
						 while($row=$result->fetch_array(MYSQLI_NUM))
						 {
							
							echo "<div id=additem >";
						
						  echo "<img src=".$row[8]." width=150px height=120px  />";
						  echo "<br/><span class=name  >".$row[2]."</span><br/><span class=price  >".$row[7]."</span><span class=ll>kyats |<a href=>Detail</a></span><br/>";
						  
					
					echo	 "<a class=linkbtn href=AddToCart.php?fid=".$row[0]." style=padding-left:0px;margin-left:0px;> Add To Cart</a>";
						   echo "</div>";
						   $row++;
						 }
						}
						else
						{
						 echo "<span style=color:#999;font-size:16px;margin-top:20px;margin-bottom:10px; >There is no data related with search keywords  !</span>";
						}
			?>
           


  </form>
        </div>
        <div style="clear:left;height:20px;"></div>
    </div>
<div class="menu_place">
    	<div class="menu">
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT ( C ) 2016 | HIPSTER </span>
                </div>
                	<div style="width:50%;float:right;">
                     	<a href="AdminLogin.php" style="float:right;">Admin Area</a>
                </div>
        </div>
    </div>    
</div>
</body>
</html>
