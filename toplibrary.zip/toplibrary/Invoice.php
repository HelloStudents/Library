<?php
session_start();
include ("advance_control.php");


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="jquery.datepick.js"></script>
<script type="text/javascript">
$(function() {
	$('#popupDatepicker').datepick();
$('#popupDatepicker1').datepick();
});
</script>
    <style type="text/css">
@import "flora.datepick.css";
</style>

<style type="text/css">
    position:relative;
    overflow:hidden;
	border:none;
}
 
.caption {
    position:absolute;
    top:0;
    right:0;
    background:rgba(66, 139, 202, 0.75);
    width:100%;
    height:100%;
    padding:2%;
    display: none;
    text-align:center;
    color:#fff !important;
    z-index:2;
}
</style>
</head>

<body >
<div class="menu_place" style="margin-top:5px;">
    	<div class="menu">
        <?php include("menudata.php"); ?>

     
        </div>
    </div>
<div class="container">
	   <div class="mcontent" >
    <img src="img/logo.fw.png" width="1100px" height="150px" />
   
    
 <hr class="palred_hr" />
    	
        <div class="r_content"  >
        <h2 style="color:#333;margin-tope:2px;margin-bottom:5px;"> Invoice Form</h2>
        <p>Dear <?php echo $_SESSION["customername"]; ?>,</p>
        <p>We receive your booking and reply you within one business day.Thank you for using our service and following is your invoice form.</p>
      
     
            <form action="Registration.php" enctype="multipart/form-data" method="post"/>
            
<?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg']."<br/>";
				 }
				?>
              
     <?php
              		
					  $query="SELECT * from invoice WHERE booking='".$_GET["booking"]."'";
					  
					 
					$mysqli=connect();
						 $result=$mysqli->query($query);
						 $row_data= $result->fetch_assoc();
	                 echo "<table>";
					 echo "<tr>";
					 echo "<td>Invoice ID</td><td>".$row_data["invoiceid"]."</td>";
					  echo "<tr>";
					   echo "<tr>";
					 echo "<td>Start Date</td><td>".$row_data["fromdate"]."</td>";
					  echo "<tr>";
					  echo "<tr>";
					 echo "<td>End Date</td><td>".$row_data["todate"]."</td>";
					  echo "<tr>";
					  echo "<tr>";
					 echo "<td>Pick up Point</td><td>".$row_data["pickuppoint"]."</td>";
					  echo "<tr>";
					  echo "<tr>";
					 echo "<td>Special Requirement</td><td>".$row_data["specialrequirement"]."</td>";
					  echo "<tr>";
					  echo "<tr>";
					 echo "<td>Total Amount</td><td>".$row_data["total"]."</td>";
					  echo "<tr>";
					  echo "</table>";
					  
			?>
           


  </form>
        </div>
         <div style="clear:both;"></div>
      
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT (C) 2016 | HIPSTER </span>
                </div>
                	<div style="width:50%;float:right;">
                     	<a href="AdminLogin.php" style="float:right;color:#C4343F;text-decoration:none;display:block;height:35px;line-height:35px;">Administration</a>
                </div>
       
    </div>
    
</div>
</body>
</html>
