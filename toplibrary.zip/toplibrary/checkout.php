<?php
session_start();
include ("advance_control.php");
$total=0;
		$tmp=array("","","","","","","","","","","","","","");
		
		$pickuppoint="";
		
		
		
		
		
		if(isset($_SESSION["customer"]))
{
	

	if(isset($_POST["checkout"]))
   {
	$CustomerId=$_SESSION["customer"];
	$bookingid=$_POST["bookingid"];
	$bookingdate =$_POST["bookingdate"];
	$pickuppoint=$_POST["pickuppoint"];
	$fromdate=$_POST["fromdate"];
		$todate=$_POST["todate"];
			$pickuppoint=$_POST["pickuppoint"];
				$expiredate=$_POST["expiredate"];
	$CustomerID=$_SESSION['customer'];

	$cardno=$_POST["cardno"];
	$cardtype=$_POST["cardtype"];
	$specialrequirement=$_POST["specialrequirement"];
	$total=$_POST["total"];

	$data=array($bookingid,$CustomerID,$bookingdate,$pickuppoint,$fromdate,$todate,$cardno,$cardtype,$expiredate,$specialrequirement,$total,"not");
	
	saveData($data,"booking");

	$id=  getID("invoice","invoiceid","IN-",6,"IN-000001");
	$data=array($id,$bookingdate,$bookingid,$_SESSION['customername'],$pickuppoint,$fromdate,$todate,$specialrequirement,$total,"","none");
	saveData($data,"invoice");

	   for($i=0;$i<count($_SESSION['itm']);$i++)
	   {
         

		
		  $personid=$_SESSION['itm'][$i][0];
		 // $qty=$_SESSION['itm'][$i][2];
		  $price=$_SESSION['itm'][$i][3]*8;
			  		  
			   
			 $data=array($bookingid,$personid,$price);
		saveData($data,"assignbooking");
	
		
	   }
	   	unset( $_SESSION['itm']);
		 for($i=0;$i<count($_SESSION['car']);$i++)
	   {
         

		
		  $carid=$_SESSION['car'][$i][0];
		 // $qty=$_SESSION['itm'][$i][2];
		  $price=$_SESSION['car'][$i][2];
			  		  
			   
			 $data=array($carid,$bookingid,$price);
		saveData($data,"carbooking");
	
		
	   }
	   	unset($_SESSION['car']);
			unset( $_SESSION['person']);
			unset( $_SESSION['travel']);
			  header("location:Invoice.php?booking=".$bookingid);

   }
	
			


}
else
{
   header("location:Customer.php?msg=Please Login first !");
}
		

			


 $total=0;
      if(isset($_SESSION['itm']))
	  {
		
	     for($z=0;$z<count( $_SESSION['itm']);$z++)
		 { 
		
		 $total=$total+($_SESSION['itm'][$z][2]*$_SESSION['itm'][$z][3]);
		 }
	  }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />
<script type="text/javascript" src="jquery-1.11.3.js"></script>
<script type="text/javascript">
 $(document).ready(function(e) 
 {
	 calculate();
     $('#itype').change(function()
      {
		     var type=$(this).val();
			 var area=$('#farea');
			
			
			   $.ajax({
			      
			   type: 'POST',
			   url: 'addperson.php',
			   data: 'type='+type,
			   success: function(msg){
				//alert(msg);
		  area.html(msg);
		  calculate();
				
			   }
			   
			   });
			
	  });
});
function calculate()
{
$.ajax({
			      
			   type: 'POST',
			   url: 'calculation.php',
			   success: function(msg){
				//alert(msg);
		  $('#total').val(msg);
		  
				
			   }
			   
			   });
}
</script>
</head>

<body>
<div class="container">
	<div class="menu_place">
    	<div class="menu">
          <?php include("menudata.php"); ?>
        </div>
    </div>
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <hr class="palblue_hr" />
    	<div class="l_content" style="width:300px;">
      <h4>  Selected Car To Rent</h4>
    <?php
    	if(isset($_SESSION["car"]))
		{
			echo "<table border=1>";
			echo "<tr><th>Car Model</th><th>Rent Price(Per day)</th></tr>";
			for($i=0;$i<count($_SESSION["car"]);$i++)
			{
				echo "<tr>";
				
				echo "<td><img src=".$_SESSION["car"][$i][3]." width=60px height=60px /><br/>".$_SESSION["car"][$i][1]."</td>";
				echo "<td>".$_SESSION["car"][$i][2]."</td>";
				echo "</tr>";
			}
			echo "</table>";
		}
	?>
        <?php
		 if(isset($_REQUEST["ctype"]))
		 {
		?>
        <h4>Employee for car</h4>
        <hr class="palgrey_hr"/>
        <form id="file-form" class="form-signin" onsubmit="false" method="post" data-toggle="validator" role="form">
        <table class="tform" >
        <tr>
                                <td >Employee Type</td></tr><tr><td><select name="persontype" class="green" id="itype">
                                          <option selected="selected">Choose One</option>
                                            <option>driver</option>
                                            <option>nurse</option>
                                            <option>doctor</option>
                                            <option>worker</option>
                         </select></td>
                            </tr>
         	         
                     <tr>
                                <td >
                               	 <div id="farea" >
     
   					 </div>
                                </td>
                            </tr>
        </table>
        <div id="resultarea">
        </div>
        </form>
         <?php
		 }
		 else
		 {
		?>
         <p>If you want to make booking with driver ,nurse ,worker ,toursit guide ,please click following custom service.</p>
    <a href="checkout.php?ctype=custom" name="cls" id="cls" style="display:block;background-color:#CCC;height:45px;line-height:45px;color:#930;width:230px;text-align:center;text-decoration:none;border:#CCC thin solid;" >Get Custom Service</a>
        <?php
		 }
		?>
    
        </div>
        <div class="r_content" style="width:580px;">
            <form action="checkout.php" enctype="multipart/form-data" method="post"/>
<?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg'];
				 }
				?>
<table class="tform" style="margin-left:30px;border:#666 thin solid;padding:20px;" cellpadding="5px" align="center">
<tr>
	<td colspan="2">Booking Form</td>
</tr>
                	<tr>
                    	<td>Booking No:</td>
                        <td><input type="text" name="bookingid" size="40" value="<?php echo getID("booking","bookingid","BO-",6,"BO-000001") ?>"  /></td>
                    </tr>
                    <tr>
                    	<td>Booking Date:</td>
                        <td><input type="text" name="bookingdate"  size="40" value="<?php echo getTodayDate( ); ?>"/></td>
                    </tr>
                          	<td>From Date:</td>
                        <td><input type="text" name="fromdate"  size="40" value="<?php echo $_SESSION['travel'][0]; ?>" /></td>
                   <tr>
                    	<td>To Date:</td>
                        <td><input type="text" name="todate"  size="40" value="<?php echo $_SESSION['travel'][2]; ?>" readonly="readonly"/></td>
                    </tr>
                     <tr>
                    	<td>Pick up Point:</td>
                        <td><input type="text" name="pickuppoint"  size="40" value="<?php echo $pickuppoint; ?>"  required="required"/></td>
                    </tr>
                    <tr>
                    	<td>Card Number:</td>
                        <td><input name="cardno" type="text" value=""  size="40" required="required"/></td>
                    </tr>
                    <tr>
                    	<td>Card Type:</td>
                        <td><select name="cardtype" ><option>Ayawaddy MPU</option><option>KBZ MPU</option></select></td>
                    </tr>
                    </tr>
                     <tr>
                    	<td>Special Requirement:</td>
                        <td><textarea name="specialrequirement" cols="37" required="required"></textarea></td>
                    </tr>
                     <tr>
                    	<td>Expire Date:</td>
                        <td><input name="expiredate" type="text" id="expiredate" value=""  size="40" required="required"/></td>
                    </tr>
                    <tr>
                    	<td>Total:</td>
                        <td><input type="text" name="total"  id="total" size="40" value="<?php echo $total;?>" readonly="readonly"/></td>
                    </tr>
                    <tr>
                    	<td></td>
                        <td><input type="submit" name="checkout" value="Check Out" /></td>
                    </tr>
    	</table>
              
   
      

  </form>
        </div>
        <div style="clear:left;height:20px;"></div>
        <div style="clear:both;"></div>
      
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT (C) 2017 | EASY WAY </span>
                </div>
                	<div style="width:50%;float:right;">
                     	<a href="AdminLogin.php" style="float:right;color:#C4343F;text-decoration:none;display:block;height:35px;line-height:35px;">Administration</a>
                </div>
    </div>
   
</div>
<script type="text/javascript">
$(document).ready(function(e) {
     calculate();

$( '#file-form' )
  .submit( function( e ) {
	
	//http://192.168.43.4/ricco/index.php/admin/enquirycontrol/jsonsave
    $.ajax( {
   url:"personaddtocart.php",
      type: 'POST',
      data: new FormData( this ),
      processData: false,
      contentType: false,
	  success: function(msg)
	  { 
 calculate();
       $('#resultarea').html(msg);
	  }
	  
                      
    } );
    e.preventDefault();
  } );
});
 
   
</script>
</body>
</html>
