<?php
session_start();
$status="Save"; 
$msg="";
$SupplierID="";
$SupplierName="";
$BookOverview="";
$Phone="";
$ISBNNumber="";
$PublishDate="";


	include("advance_control.php");
$BookID=getID("book","BookID","B-",5,"B-00001");
	$total=0;
     
 if(isset($_REQUEST['m']))
   {
	  $msg=$_REQUEST['m'];
   
   }

   if(isset($_REQUEST['btn']))
   {
	   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $mysqli = new mysqli('localhost','root','','top');

	// if ($mysqli->connect_error) {
		//die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		//}
	   if($_REQUEST['btn']=="Save")
	   {
$destination="";
			
				   if($_FILES['file']['name']!="")
				   {
					  $newImage=$_FILES['file']['name'];                    
			
					  $destination="book/".$newImage;
					  $action=copy( $_FILES['file']['tmp_name'],$destination );
			
				   }
				   if($_FILES['file2']['name']!="")
				   {
					  $newImage2=$_FILES['file2']['name'];                    
			
					  $destination2="pdf/".$newImage2;
					  $action=copy( $_FILES['file']['tmp_name'],$destination2 );
			
				   }
				//   echo $_POST['ItemID'],$_POST['Itemname'],$_POST['Qty'],$_POST['Price'],"0",$_POST['Description'],$_POST['itype'],$destination;
		
				
				$BookID=getID("book","BookID","B-",5,"B-00001");
$data=array($BookID,$_POST['BookName'],$_POST['CategoryID'],$_POST['PublisherID'],$_POST['BookOverview'],$destination,$_POST['ISBNNumber'],$_POST['PublishDate'],"0","0",$destination2);

saveData($data,"book");


		
	header("location:abookList.php?msg=Successfully Save !");
			
		
	  	 }
		 else
		 {
		 }
 
       }


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />
<script type="text/javascript" src="jquery-1.9.1.js"></script>


</head>

<body>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <div class="menu_place">
    	<div class="menu">
     <?php include("menudata.php"); ?>
        </div>
    </div>
    	<div class="l_content">
        	<ul id="sidemenu">
            	<li class="smtitle ">Entry</li>
        <li>  <a href=""  >Book Category </a></li>
          <li> <a href="SupplierList.php" class="act" >Supplier List </a></li>
         <li>  <a href="abooklist.php"  >Book List </a></li>
            	
            </ul>
        </div>
        <div class="r_content" >
            <form action="BookRegistration.php" method="post" enctype="multipart/form-data">
            
            <table class="tform"  style="margin-left:30px;">
                <tr>
                    <td colspan="2"><h3>book Registration</h3><hr class="palblue_hr"/> </td>
                </tr>
                
                            <tr>
                                <td >book ID</td><td><input name="BookID" type="text" value="<?php echo $BookID;?>" readonly="readonly" /></td>
                            </tr>
                             
                            <tr>
                                <td >book Name</td><td><input type="text" name="BookName" value="<?php echo $SupplierName; ?>" /></td>
                            </tr>
                            <tr>
                                <td valign="top">Book Over view</td><td><textarea cols="20" rows="5" name="BookOverview"  ><?php echo $BookOverview; ?></textarea></td>
                            </tr>
                                <tr>
                                <td >Publish Date</td><td><input type="text" name="PublishDate" value="<?php echo $PublishDate; ?>" /></td>
                            </tr>
                               </tr>
                                <tr>
                                <td >ISBN Number</td><td><input type="text" name="ISBNNumber" value="<?php echo $ISBNNumber; ?>" /></td>
                            </tr>
                             <tr>
                             	<td>Book Category</td>
                                <td> <?php fillToCombowithtitle("bookcategory",1,"CategoryID","Choose Category")?></td>
                             </tr>
                           <tr>
                             	<td>Publisher</td>
                                <td>  <?php fillToCombowithtitle("publisher",1,"PublisherID","Choose Publisher")?></td>
                             </tr>
                            
                             <tr>
                               <td><input type="hidden" name="qty" value="0"  readonly="readonly"/><td><input type="hidden" name="NumberofCopies" value="0" /></td>
                            </tr>
                           
                     <tr>
                                <td colspan="2">
                               	 <div id="farea" >
     
   					 </div>
                                </td>
                            </tr>
                             <tr>
             <td>Image</td> <td>     <input type="file" name="file"  	 class="green" style="width:200px;"/></td>
              
             </tr>
               <tr>
             <td>Pdf</td> <td>     <input type="file" name="file2"  	 class="green" style="width:200px;"/></td>
              
             </tr>
              <tr>
                                <td ></td><td><input type="submit" name="btn" value="<?php  echo $status;?>" /></td>
                            </tr>
            
             <tr>
             	<td colspan="2">
                
             </tr>
              
                             <tr>
                                <td colspan="2"><hr class="palblue_hr"/>  </td>
                            </tr>
            </table>
              </form>
           
        </div>
        <div style="clear:left;height:20px;"></div>
        <div class="menu_place">
    	
    </div>  
    </div>
  
</div>
</body>
</html>
