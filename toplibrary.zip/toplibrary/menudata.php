<?php
if(isset($_SESSION["administrator"]))
{
?>
<a href="home.php?type=Logout"> Logout</a>
<a href="stafflist.php">Staff List</a>

<a href="abooklist.php">Book List</a>
<a href="Purchase.php">Purchase</a>
<a href="SupplierList.php">Supplier</a>
<a href="CategoryList.php">Book Category</a>
<a href="searchandreport.php">Search & Report</a>
<?php
}
else if(isset($_SESSION["member"]))
{
?>
 <a href="home.php"> Home </a>
  <a href="Mylibrary.php"> My Library </a>
<a href="home.php?type=Logout"> Logout</a>
<a href="Booklist.php"> Book List</a>
  
         
 <?php
 $ti=0;
  if(isset($_SESSION['itm']))
	 {
	 
	   
	     echo "<a href=checkout.php>Check Out</a>";

	 echo "<a href=myitem.php>My Item ( ".count($_SESSION['itm'])." )</a>";
  }
  
}
else
{
?>
 <a href="home.php">Home</a>
         <a href="Member.php"  >Member Registration</a>
          <a href="Home.php"  >Member Login</a>
        <a href="Booklist.php"  >Book List</a>
          
          

<?php
}
?>
  