<?php
session_start();
$status="Create  Account"; 
$msg="";
$MemberID="";
$MemberName="";
$Address="";
$Phone="";
$Email="";
$Password="";
$amsg="";
$Age="";
	include("advance_control.php");

   if(isset($_REQUEST['amsg']))
   {
	  $amsg=$_REQUEST['amsg'];
   
   }
  

   $MemberID= getID("member","MemberID","M-",6,"M-000001");
  // echo "sds".$id;

   
   if(isset($_REQUEST['btn']))
   {
	   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $mysqli = new mysqli('localhost','root','','top');

	// if ($mysqli->connect_error) {
		//die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		//}
	   if($_REQUEST['btn']=="Create  Account")
	   {

	  $insert_row = $mysqli->query( "INSERT INTO member VALUES ('".$_REQUEST['MemberID']."','".$_REQUEST['MemberName']."','"
	  .$_REQUEST['Address']."','".$_REQUEST['Age']."','".$_REQUEST['Phone']."','".$_REQUEST['Email']."','".$_REQUEST['Password']."','0','','','disable')");
	  $t=array($_REQUEST['MemberID'],$_REQUEST['MemberName'],$_REQUEST['Address'],$_REQUEST['Email']);
	$_SESSION["stillnewinfo"]=$t;
			if($insert_row)
			{
				$_SESSION["stillnew"]=$_REQUEST['MemberID'];
				header("Location: MemberPayment.php");
			}
			else
			{
		die('Error : ('. $mysqli->errno .') '. $mysqli->error);
			}
		$mysqli->close();
	  	 }
		
 
       }


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>

<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <div class="menu_place">
    	<div class="menu">
           <?php include("menudata.php"); ?>
        </div>
    </div>
    	<div class="l_content"  style="width:400px;">
        	 <h3>Welcome To MemberRegistration</h3>
             <p>There are two step in member registration and first step is following from and second step is filling payment data.</p>
        </div>
        <div class="r_content"  style="width:600px; ">
            <form action="Member.php" method="post">
            
            <table class="tform"  style="margin-left:30px;border:#666 thin solid;padding:20px;" cellpadding="5px" align="center">
                <tr>
                    <td colspan="2"><h3>Member Registration</h3><hr class="palblue_hr"/> </td>
                </tr>
                <tr>
                    <td colspan="2"><span class="vc"><?php echo $amsg; ?></span></td>
                </tr>
                <tr>
                    <td ></td><td><input name="MemberID" type="hidden" value="<?php echo $MemberID;?>" readonly="readonly" /></td>
                </tr>
                <tr>
                    <td >Member Name</td><td><input type="text" name="MemberName" value="<?php echo $MemberName; ?>" required="required" /></td>
                </tr>
                <tr>
                    <td valign="top">Address</td><td><textarea cols="20" rows="5" name="Address"  ><?php echo $Address; ?></textarea></td>
                </tr>
                 <tr>
                    <td >Age</td><td><input type="text" name="Age" value="<?php echo $Age; ?>" /></td>
                </tr>
                 <tr>
                    <td >Phone</td><td><input type="text" name="Phone" value="<?php echo $Phone; ?>" /></td>
                </tr>
                 <tr>
                    <td >Email</td><td><input type="text" name="Email" value="<?php echo $Email; ?>" required="required" /></td>
                </tr>
                 <tr>
                    <td >Password</td><td><input type="password" name="Password" value="<?php echo $Password; ?>" required="required"/></td>
                </tr>
                <tr>
                    <td ></td><td><input type="submit" name="btn" value="<?php  echo $status;?>" /></td>
                </tr>
                 <tr>
                    <td colspan="2"><hr class="palblue_hr"/>  </td>
                </tr>
            </table>
            </form>
        </div>
        <div style="clear:left;height:20px;"></div>
           <?php include("footer.php"); ?>
</body>
</html>
