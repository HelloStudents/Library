<?php
session_start();
include("advance_control.php");
  if(isset($_REQUEST['type']))
  {
	  $t=$_REQUEST['type'];
	  $result=search("SELECT * FROM invoice where  invoiceid='".$_REQUEST['type']."'");
	  	$row=$result->fetch_assoc();
		echo	$row["invoiceid"]."&".
$row["customername"]."&".
$row["pickuppoint"]."&".
$row["total"];
  }
  if(isset($_REQUEST['del']))
  {
	 // $t=$_REQUEST['type'];
	  $result=search("SELECT * FROM payment	 where  paymentID='".$_REQUEST['del']."'");
	   	$row=$result->fetch_assoc();
	  echo	$row["SaleID"]."&".
$row["deliveryaddress"]."&".
$row["amount"];
  }
?>