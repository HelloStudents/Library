<div style="width:50%;float:left; background-color:#CECEB9;">
                     <span style="display:block;height:45px;line-height:45px;color:#FFF;margin-left:20px;">COPY RIGHT (C) 2017 | TOP LIBRARY SYSTEM </span>
                </div>
                	<div style="width:50%;float:right; background-color:#CECEB9;">
                     	<a href="AdminLogin.php" style="float:right;color:#000000;padding-right:15px; text-decoration:none;display:block;height:45px;line-height:45px;">Administration</a>
        
    </div>
       
    </div>
    
</div>