<?php
session_start();
$status="Create  Account"; 
$msg="";
$CustomerID="";
$CustomerName="";
$Address="";
$Phone="";
$Email="";
$Password="";
if(isset($_GET["type"]))
{
  unset($_SESSION["member"]);
  unset($_SESSION["administrator"]);
  unset($_SESSION["itm"]);
   	unset($_SESSION['car']);
			unset( $_SESSION['person']);
			unset( $_SESSION['travel']);
}

	include("advance_control.php");
 if(isset($_REQUEST['msg']))
   {
	  $msg=$_REQUEST['msg'];
   
   }
  

   if(isset($_REQUEST["rid"]))
   {
	     $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $mysqli = new mysqli('localhost','root','','top');
	    $result = $mysqli->query("SELECT * FROM member WHERE MemberID ='".$_SESSION["member"]."'");
		//row_data= $result->
		$row=$result->fetch_assoc();
	
		$totalcopy=	$row["Points"];
		
$points=(int)$totalcopy;
		//row_data= $result->
		$row=$result->fetch_assoc();
	   echo "<script>alert('".$points."');</script>";
	 $borrowid= getID("reserve","ReserveID","R-",6,"R-000001");
	 $to=getTodayDate( );
		//$end=date('m/d/Y', strtotime( $to.' + 14 days'));
		
		if($points<20)
		{
			header("Location: PointPurchase.php?msg=Buy Points first for purchase !");
		}
		else
		{
		$tmp=array( $borrowid,$_SESSION["member"],$to,$points,"reserve");
			
				saveData($tmp,"reserve");
			
			$tmp=array( $borrowid,$_REQUEST["rid"],"","reservedetail");
			$points=$points-20;
				saveData($tmp,"reservedetail");	
				$sql="UPDATE member SET Points='$points' WHERE MemberID='".$_SESSION["member"]."'";
    process($sql);
	header("Location: Booklist.php?msg=Reservation Success !");
	
		}
   }


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="jquery.datepick.js"></script>
<script type="text/javascript">
$(function() {
	$('#popupDatepicker').datepick();
$('#popupDatepicker1').datepick();
});
</script>
    <style type="text/css">
@import "flora.datepick.css";
</style>

<style type="text/css">
    position:relative;
    overflow:hidden;
	border:none;
}
 
.caption {
    position:absolute;
    top:0;
    right:0;
    background:rgba(66, 139, 202, 0.75);
    width:100%;
    height:100%;
    padding:2%;
    display: none;
    text-align:center;
    color:#fff !important;
    z-index:2;
}
</style>
</head>

<body >

<div class="container">
	   <div class="mcontent" >
    <img src="img/logo.fw.png" width="1100px" height="150px" />
   
<div class="menu_place" style="margin-top:5px;">
    	<div class="menu">
        <?php include("menudata.php"); ?>

     
        </div>
    </div>
    	
       
      
        <div class="r_content"  style="width:1000px;margin:0 auto;margin-left:50px;" >
      <h3 align="center">Available Book List</h3>
      <hr class="palblue_hr"/>
<?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg']."<br/>";
				 }
				?>
              
     <?php
              		
					  $query="SELECT * from book ";
					  if(isset($_REQUEST["did"]))
					  {
						 
					    $query="SELECT * from book WHERE BookID='".$_REQUEST["did"]."'";
					  }
					  if(isset($_REQUEST["search"]))
					  {
						 
					    $query="SELECT * from product WHERE productname LIKE '%".$_REQUEST["tsearch"]."%'";
					  }
					  
					$mysqli=connect();
						 $result=$mysqli->query($query);
						 $rowcount=mysqli_num_rows( $result);
						 $row=0;
						 if($rowcount>0)
						{
						
					
						 
						
						 
						 while($row=$result->fetch_array(MYSQLI_NUM))
						 {
							
						
						   echo "<div id=additem style=width:750px >";
						    echo "<table>";
						  echo "<tr><td><img src=".$row[5]." width=150px height=120px  /></td>";
						  echo "<td valign=top>";
						  echo "<table>";
						  echo "<tr><td>Book Name:<span class=name  >".$row[1]."</span></td></tr>";
						    echo "<tr><td>Publish Date:<span class=name  >".$row[7]."</span></td></tr>";
						 echo "<tr><td>ISBN:<span class=name  >".$row[6]."</span></td></tr>";
						  echo "<tr><td>Available Book:<span class=name  >".$row[9]."</span></td></tr>";
						  echo "<tr><td colspan=2>Book Overview<br/><span class=name  >".$row[4]."</span></td></tr>";
					if(isset($_SESSION["member"]))
					{
					echo	 "<tr><td><a href=detail.php?rid=".$row[6]."&bid=".$row[0]." style=padding-left:0px;margin-left:0px;color:#666600;border:#666600 thin solid;width:100px; >Reserve Now</a></td></tr>";
					}
					
					echo "</table></td></tr></table>";
						   echo "</div>";
						   
						   $row++;
						 }
						}
						else
						{
						 echo "<span style=color:#999;font-size:16px;margin-top:20px;margin-bottom:10px; >There is no data related with search keywords  !</span>";
						}
			?>
        </div>
         <div style="clear:both;"></div>
      
    <?php include("footer.php"); ?>
       			
</body>
</html>
