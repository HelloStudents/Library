<?php
session_start();
include("advance_control.php");
if(isset($_POST["btn"]))
{
  $d=array(getID("delivery","DeliveryID","DL-",6,"DL-000001"),getTodayDate( ),$_POST["saleid"],$_POST["daddress"],$_POST["amount"]);
  saveData($d,"delivery");
  $sql="UPDATE payment SET status='deliver' WHERE paymentid='".$_POST["pid"]."'";
    process($sql);

  header("location:Delivery.php?msg=Successfully Save Payment!");
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />
<script type="text/javascript" src="jquery-1.9.1.js"></script>
<script type="text/javascript">
 $(document).ready(function(e) 
 {
     $('#pid').change(function()
      {
		     var type=$(this).val();
	
			
			
			   $.ajax({
			      
			   type: 'POST',
			   url: 'paydeliver.php',
			   data: 'del='+type,
			   success: function(msg){
				
		var d=msg.split("&");
		
		$('#saleid').val(d[0]);
		  		 $('#daddress').val(d[1]);
				  $('#amount').val(d[2]);
		  
				
			   }
			   
			   });
			
	  });
});
</script>
</head>
<body>
<div class="container">
	<div class="menu_place">
    	<div class="menu">
       <?php include("menudata.php"); ?>
        </div>
    </div>
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <hr class="palblue_hr" />
    	<div class="l_content">
        	<ul id="sidemenu">
            		<li class="smtitle ">Entry</li>
          <li>  <a href="StaffList.php"  >Staff </a></li>
          <li> <a href="CategoryList.php" class="act" >Category </a></li>
         <li>  <a href="SupplierList.php"  >Supplier </a></li>
            	
            </ul>
        </div>
        <div class="r_content" >
            <form action="Delivery.php" enctype="multipart/form-data" method="post"/>
<?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg'];
				 }
				?>
  <table>
  <tr>
  	<td colspan="2">
    <h3>Delivery</h3><hr/>
    </td>
  </tr>
  <tr>
    <td valign="top">
                 <?php
        $query = "SELECT  * from payment WHERE status='not'";
	$result = search($query);
	$rowcount = mysqli_num_rows($result);
	
	
	if ($rowcount > 0 )
	{
		
		echo "
		Payment ID <br/>
		<select name=pid id=pid size=10 onchange=Redirect() >";
		
		while($row=$result->fetch_assoc())
		{
			
		
		echo  "<option>" .$row["paymentID"]."</option>";	
	
		
			
		}
		echo "</select>";
		
	}
	
	
	?>
    </td>
     <td valign="top">
     
     <table>
            <tr>
             <td>Delivery ID</td> <td><input type="text" name="paid" class="green" value="<?php echo getID("delivery","DeliveryID","DL-",6,"DL-000001"); ?>" /></td>
              
             </tr>
              <tr>
             <td>Delivery Date</td> <td><input type="text" name="padate" class="green" id="Itemname" value="<?php echo getTodayDate( ); ?>" /></td>
              
             </tr>
             <tr>
             <td>Sale ID</td> <td><input type="text" id="saleid" name="saleid" class="green" /></td>
              
             </tr>
             <tr>
             <td>Delivery Address</td> <td><input type="text" id="daddress" name="daddress" class="green" /></td>
              
             </tr>
              <tr>
             <td>Amount</td> <td><input type="text" name="amount" id="amount" class="green"  /></td>
              
             </tr>
              
              
             <tr>
               <td colspan="2" align="right"><input type="submit" name="btn" value="Make Delivery" class="btn"  />            <hr/>
               
                </td>
             </tr>
             <tr>
            
          </table>
     </td>
  </tr>
  

<tr>
<td>
</td>
</tr>
</table>
          

  </form>
        </div>
        <div style="clear:left;height:20px;"></div>
    </div>
<div class="menu_place">
    	<div class="menu">
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT ( C ) 2016 | HIPSTER </span>
                </div>
                	<div style="width:50%;float:right;">
                     	<a href="" style="float:right;">Admin Area</a>
                </div>
        </div>
    </div>    
</div>
</body>

</html>
