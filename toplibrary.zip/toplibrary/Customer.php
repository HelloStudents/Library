<?php
session_start();
$status="Create  Account"; 
$msg="";
$MemberID="";
$MemberName="";
$Address="";
$Phone="";
$Email="";
$Password="";
$amsg="";

	include("advance_control.php");
 if(isset($_REQUEST['msg']))
   {
	  $msg=$_REQUEST['msg'];
   
   }
   if(isset($_REQUEST['amsg']))
   {
	  $msg=$_REQUEST['amsg'];
   
   }
  

   $MemberID= getID("customer","MemberID","CT-",6,"CT-000001");
  // echo "sds".$id;
  if(isset($_REQUEST['btnlogin']))
   {
	  $mysqli=connect();
	 $result = $mysqli->query("SELECT * FROM customer WHERE Email ='".$_REQUEST['UserName']."' AND Password='".$_REQUEST['Password']."'");
		//row_data= $result->
		$row=$result->fetch_assoc();
	if(mysqli_num_rows($result)>0)
	{
		$_SESSION['customer']=	$row["MemberID"];
		$_SESSION['MemberName']=	$row["MemberName"];
		if(isset($_SESSION["travel"]))
		{
		  header("Location: checkout.php");
		}
		else
		{
	header("Location: Home.php");
		}
	}
      $msg="Invalid User Name and Password !"; 
   }
   
   if(isset($_REQUEST['btn']))
   {
	   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $mysqli = new mysqli('localhost','root','','easyway');

	// if ($mysqli->connect_error) {
		//die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		//}
	   if($_REQUEST['btn']=="Create  Account")
	   {

	  $insert_row = $mysqli->query( "INSERT INTO customer VALUES ('".$_REQUEST['MemberID']."','".$_REQUEST['MemberName']."','"
	  .$_REQUEST['Address']."','".$_REQUEST['Phone']."','".$_REQUEST['Email']."','".$_REQUEST['Password']."')");
	
			if($insert_row)
			{
				header("Location: Customer.php?amsg=Successfully Create Account !");
			}
			else
			{
		die('Error : ('. $mysqli->errno .') '. $mysqli->error);
			}
		$mysqli->close();
	  	 }
		
 
       }


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>
<div class="menu_place">
    	<div class="menu">
           <?php include("menudata.php"); ?>
        </div>
    </div>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <hr class="palred_hr"/>
    	<div class="l_content"  style="width:400px;">
        	 
        </div>
        <div class="r_content"  style="width:600px; ">
            <form action="Customer.php" method="post">
            
            <table class="tform"  style="margin-left:30px;border:#666 thin solid;padding:20px;" cellpadding="5px" align="center">
                <tr>
                    <td colspan="2"><h3>Member Registration</h3><hr class="palblue_hr"/> </td>
                </tr>
                <tr>
                    <td colspan="2"><span class="vc"><?php echo $amsg; ?></span></td>
                </tr>
                <tr>
                    <td ></td><td><input name="MemberID" type="hidden" value="<?php echo $MemberID;?>" readonly="readonly" /></td>
                </tr>
                <tr>
                    <td >Customer Name</td><td><input type="text" name="MemberName" value="<?php echo $MemberName; ?>" required="required" /></td>
                </tr>
                <tr>
                    <td valign="top">Address</td><td><textarea cols="20" rows="5" name="Address"  ><?php echo $Address; ?></textarea></td>
                </tr>
                 <tr>
                    <td >Phone</td><td><input type="text" name="Phone" value="<?php echo $Phone; ?>" /></td>
                </tr>
                 <tr>
                    <td >Email</td><td><input type="text" name="Email" value="<?php echo $Email; ?>" required="required" /></td>
                </tr>
                 <tr>
                    <td >Password</td><td><input type="password" name="Password" value="<?php echo $Password; ?>" required="required"/></td>
                </tr>
                <tr>
                    <td ></td><td><input type="submit" name="btn" value="<?php  echo $status;?>" /></td>
                </tr>
                 <tr>
                    <td colspan="2"><hr class="palblue_hr"/>  </td>
                </tr>
            </table>
            </form>
        </div>
        <div style="clear:left;height:20px;"></div>
            <div style="clear:both;"></div>
      
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT (C) 2017 | EASY WAY </span>
                </div>
                	<div style="width:50%;float:right;">
                     	<a href="AdminLogin.php" style="float:right;color:#C4343F;text-decoration:none;display:block;height:35px;line-height:35px;">Administration</a>
                </div>
       
    </div>
    
</div>
</body>
</html>
