<?php
session_start();
$status="Save"; 
$msg="";
$StaffID="";
$StaffName="";
$Address="";
$Phone="";
$UserName="";


	include("advance_control.php");
 if(isset($_REQUEST['m']))
   {
	  $msg=$_REQUEST['m'];
   
   }
  
 if(isset($_REQUEST['request']))
   {
	  $status=$_REQUEST['request'];
	
     $StaffID=$_REQUEST['uid'];
	$mysqli=connect();
	 $result = $mysqli->query("SELECT * FROM Staff WHERE StaffID ='".$_REQUEST['uid']."'");
		$row_data= $result->fetch_assoc();
		 $StaffName=$row_data['StaffName'];
	 $Address=$row_data['Address'];
	 $Phone=$row_data['Phone'];
 
		$UserName=$row_data['UserName'];

   }
   else
   {
   $StaffID= getID("staff","StaffID","ST-",3,"ST-001");
  // echo "sds".$id;
   }
   if(isset($_REQUEST['btn']))
   {
	   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = 'eas';
   $mysqli = new mysqli('localhost','root','','top');

	// if ($mysqli->connect_error) {
		//die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		//}
	   if($_REQUEST['btn']=="Save")
	   {

	  $insert_row = $mysqli->query( "INSERT INTO staff VALUES ('".$_REQUEST['StaffID']."','".$_REQUEST['StaffName']."','"
	  .$_REQUEST['Address']."','".$_REQUEST['Phone']."','".$_REQUEST['UserName']."','".$_REQUEST['Password']."')");
	
			if($insert_row)
			{
				header("Location: StaffList.php?msg=Successfully Save !");
			}
			else
			{
		die('Error : ('. $mysqli->errno .') '. $mysqli->error);
			}
		$mysqli->close();
	  	 }
		 else
		 {
			 $sql="UPDATE staff SET StaffName='".$_REQUEST['StaffName']."', Address='".$_REQUEST['Address']
			 ."', Phone='".$_REQUEST['Phone']."', UserName='".$_REQUEST['UserName']."', Password='".$_REQUEST['Password']."' WHERE StaffID='".$_REQUEST['StaffID']."'";
		 $results = $mysqli->query($sql);

			//MySqli Delete Query
			//$results = $mysqli->query("DELETE FROM products WHERE ID=24");
			
			if($results){
				header("Location: StaffList.php?msg=Successfully Update !");
			}else{
				print 'Error : ('. $mysqli->errno .') '. $mysqli->error;
			}
		 }
 
       }


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>
<div class="container">

    <div class="mcontent">
    <img src="img/logo.fw.png" />
	<div class="menu_place">
    	<div class="menu">
       <?php include("menudata.php"); ?>
        </div>
    </div>
    	<div class="l_content">
        	<ul id="sidemenu">
            	<li class="smtitle ">Entry</li>
        <li>  <a href=""  >Book Category </a></li>
          <li> <a href="SupplierList.php" class="act" >Supplier List </a></li>
         <li>  <a href="abooklist.php"  >Book List </a></li>
            	
            </ul>
        </div>
        <div class="r_content" >
            <form action="Staff.php" method="post">
            
            <table class="tform"  style="margin-left:30px;">
                <tr>
                    <td colspan="2"><h3>Staff Registration</h3><hr class="palblue_hr"/> </td>
                </tr>
                
                <tr>
                    <td >Staff ID</td><td><input name="StaffID" type="text" value="<?php echo $StaffID;?>" readonly="readonly" /></td>
                </tr>
                <tr>
                    <td >Staff Name</td><td><input type="text" name="StaffName" value="<?php echo $StaffName; ?>" /></td>
                </tr>
                <tr>
                    <td valign="top">Address</td><td><textarea cols="20" rows="5" name="Address"  ><?php echo $Address; ?></textarea></td>
                </tr>
                 <tr>
                    <td >Phone</td><td><input type="text" name="Phone" value="<?php echo $Phone; ?>" /></td>
                </tr>
                 <tr>
                    <td >User Name</td><td><input type="text" name="UserName" value="<?php echo $UserName; ?>" /></td>
                </tr>
                 <tr>
                    <td >Password</td><td><input type="password" name="Password"  /></td>
                </tr>
                <tr>
                    <td ></td><td><input type="submit" name="btn" value="<?php  echo $status;?>" /></td>
                </tr>
                 <tr>
                    <td colspan="2"><hr class="palblue_hr"/>  </td>
                </tr>
            </table>
            </form>
        </div>
        <div style="clear:left;height:20px;"></div>
        <div class="menu_place">
    	<div class="menu">
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT ( C ) 2016 | TOP LIBRARY SYSTEM </span>
                </div>
                	<div style="width:50%;float:right;">
                     	<a href="" style="float:right;">Admin Area</a>
                </div>
        </div>
    </div>
    </div>
    
</div>
</body>
</html>
