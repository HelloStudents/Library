-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2017 at 05:52 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `top`
--
CREATE DATABASE IF NOT EXISTS `top` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `top`;

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `AuthorID` varchar(50) NOT NULL,
  `AuthorName` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `BookID` varchar(50) NOT NULL,
  `BookName` varchar(50) NOT NULL,
  `CategoryID` varchar(50) NOT NULL,
  `PublisherID` varchar(50) NOT NULL,
  `BookOverview` varchar(300) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `ISBNNumber` varchar(50) NOT NULL,
  `PublishDate` varchar(50) NOT NULL,
  `Qty` varchar(45) NOT NULL,
  `NumberofCopies` varchar(45) NOT NULL,
  `filepath` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`BookID`, `BookName`, `CategoryID`, `PublisherID`, `BookOverview`, `Image`, `ISBNNumber`, `PublishDate`, `Qty`, `NumberofCopies`, `filepath`) VALUES
('B-00001', ' English Speaking and Grammar through Hindi', 'C-001', 'P-001', 'Learn English speaking and grammar throu', 'book/img1.jpg', '21312312', '2017', '3', '2', 'pdf/7habit.pdf'),
('B-00002', ' Forbidden Fantasy', 'C-002', 'P-001', ' Forbidden Fantasy  It all began with a stolen ki', 'book/img2.jpg', '21313123', '2017', '3', '2', 'pdf/7habit.pdf'),
('B-00003', 'daf', 'Horror', 'Penguin', 'adsfa', 'book/yellow.jpg', 'adsfa', 'daf', '0', '0', 'pdf/case_study_3-2.pdf'),
('B-00004', 'daf', 'Horror', 'Penguin', 'asdf', 'book/images.jpg', 'asdf', 'daf', '0', '0', 'pdf/case_study_3-2.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `bookauthor`
--

CREATE TABLE `bookauthor` (
  `BookID` varchar(50) NOT NULL,
  `AuthorID` varchar(50) NOT NULL,
  `Remark` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bookcategory`
--

CREATE TABLE `bookcategory` (
  `categoryID` varchar(45) NOT NULL,
  `categoryname` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookcategory`
--

INSERT INTO `bookcategory` (`categoryID`, `categoryname`, `description`) VALUES
('C-001', 'Horror', '-'),
('C-002', 'Thriller', '-');

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `BorrowID` varchar(50) NOT NULL,
  `MemberID` varchar(50) NOT NULL,
  `BorrowDate` varchar(50) NOT NULL,
  `BorrowEndDate` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Numbersofbooks` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`BorrowID`, `MemberID`, `BorrowDate`, `BorrowEndDate`, `Description`, `Numbersofbooks`, `Status`) VALUES
('B-000001', 'M-000008', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000002', 'M-000008', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000003', 'M-000008', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000004', 'M-000008', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000005', 'M-000008', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000006', 'M-000008', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000007', 'M-000008', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000008', 'M-000008', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000009', 'M-000008', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000010', 'M-000009', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000011', 'M-000009', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000012', 'M-000009', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000013', 'M-000009', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('B-000014', 'M-000009', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('BR-000001', 'M-000010', '04/29/2017', '05/13/2017', '-', '1', 'borrow'),
('BR-000002', 'M-000010', '04/29/2017', '05/13/2017', '-', '1', 'borrow');

-- --------------------------------------------------------

--
-- Table structure for table `borrowdetail`
--

CREATE TABLE `borrowdetail` (
  `BorrowID` varchar(50) NOT NULL,
  `BookID` varchar(50) NOT NULL,
  `BorrowDate` varchar(50) NOT NULL,
  `ReturnDate` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `borrowdetail`
--

INSERT INTO `borrowdetail` (`BorrowID`, `BookID`, `BorrowDate`, `ReturnDate`, `Status`) VALUES
('B-000001', 'B-00002', '04/29/2017', '05/13/2017', 'return'),
('B-000002', 'B-00002', '04/29/2017', '05/13/2017', 'return'),
('B-000003', 'B-00002', '04/29/2017', '05/13/2017', 'return'),
('B-000004', 'B-00002', '04/29/2017', '05/13/2017', 'return'),
('B-000005', 'B-00001', '04/29/2017', '05/13/2017', 'return'),
('B-000006', 'B-00002', '04/29/2017', '05/13/2017', 'return'),
('B-000007', 'B-00001', '04/29/2017', '05/13/2017', 'return'),
('B-000008', 'B-00002', '04/29/2017', '05/13/2017', 'borrow'),
('B-000009', 'B-00001', '04/29/2017', '05/13/2017', 'borrow'),
('B-000010', 'B-00002', '04/29/2017', '05/13/2017', 'return'),
('B-000011', 'B-00001', '04/29/2017', '05/13/2017', 'return'),
('B-000012', 'B-00002', '04/29/2017', '05/13/2017', 'return'),
('B-000013', 'B-00002', '04/29/2017', '05/13/2017', 'return'),
('B-000014', 'B-00002', '04/29/2017', '05/13/2017', 'return'),
('BR-000001', 'B-00002', '04/29/2017', '05/13/2017', 'borrow'),
('BR-000002', 'B-00001', '04/29/2017', '05/13/2017', 'borrow');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `MemberID` varchar(50) NOT NULL,
  `MemberName` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Age` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Points` varchar(50) NOT NULL,
  `MemberRegistrationDate` varchar(50) NOT NULL,
  `MemberExpiredDate` varchar(50) NOT NULL,
  `status` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`MemberID`, `MemberName`, `Address`, `Age`, `Phone`, `Email`, `Password`, `Points`, `MemberRegistrationDate`, `MemberExpiredDate`, `status`) VALUES
('M-000001', 'Min war', 'No 12', '12', '1245666', 'test@gmail.com', '12345678', '0', '', '', 'disable'),
('M-000002', 'Min war', 'dsf', '12', '1245666', 'test@gmail.com', '12345678', '0', '', '', 'disable'),
('M-000003', 'Min war', 'No 11', '12', '1245666', 'minwar@gmail.com', 'minwar2017', '0', '', '', 'disable'),
('M-000004', 'Min war', 'wewe', '12', '1245666', 'minwar2@gmail.com', 'minwar2', '0', '', '', 'disable'),
('M-000005', 'Min war', 'asdf', '12', '1245666', 'minwar2@gmail.com', 'minwar2', '0', '', '', 'disable'),
('M-000006', 'Min war', 'adsfa', 'as', 'asdf', 'fasdfasdfasd', 'asfasdf', '0', '', '', 'disable'),
('M-000007', 'Min war', 'asfd', 'fa', 'ads', 'fasdfas', 'fasfasfa', '100', '04/29/2017', '04/29/2018', 'activate'),
('M-000008', 'Min war', 'No(123)', '12', '1245666', 'minwar23@gmail.com', 'minwar23', '200', '04/29/2017', '04/28/2020', 'activate'),
('M-000009', 'Min war', 'gg', '12', '1245666', 'minwar27@gmail.com', 'minwar27', '280', '04/29/2017', '04/29/2019', 'activate'),
('M-000010', 'Tun thein', 'tttt', '23', '4123123', 'tunthein@gmail.com', 'tunthein', '100', '04/29/2017', '04/29/2019', 'activate');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PaymentID` varchar(50) NOT NULL,
  `PaymentDate` varchar(50) NOT NULL,
  `MemberID` varchar(50) NOT NULL,
  `CardNo` varchar(50) NOT NULL,
  `CardType` varchar(50) NOT NULL,
  `ExpiredDate` varchar(50) NOT NULL,
  `totalamount` varchar(50) NOT NULL,
  `Status` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PaymentID`, `PaymentDate`, `MemberID`, `CardNo`, `CardType`, `ExpiredDate`, `totalamount`, `Status`) VALUES
('PY-000001', '04/29/2017', 'M-000004', '', '', '', '', ''),
('PY-000002', '04/29/2017', 'M-000005', '', '', '', '', ''),
('PY-000003', '04/29/2017', 'M-000006', '', '', '', '', ''),
('PY-000003', '04/29/2017', '', '3112123', 'Ayawaddy MPU', '211221', '', ''),
('PY-000004', '04/29/2017', 'M-000007', '3112123', 'Ayawaddy MPU', '211221', '', ''),
('PY-000005', '04/29/2017', 'M-000008', '3112123', 'Ayawaddy MPU', '20/04/2016', '', ''),
('PY-000006', '04/29/2017', '', '3112123', 'Ayawaddy MPU', '20/04/2016', '', 'registrationfees'),
('PY-000007', '04/29/2017', '', '3112123', 'KBZ MPU', '211221', '', 'registrationfees'),
('PY-000008', '04/29/2017', '', '3112123', 'Ayawaddy MPU', '20/04/2016', '', 'renewfees'),
('PY-000009', '04/29/2017', 'M-000008', '3112123', 'Ayawaddy MPU', '211221', '', 'renewfees'),
('PY-000010', '04/29/2017', 'M-000008', '3112123', 'Ayawaddy MPU', '211221', '', 'renewfees'),
('PY-000011', '04/29/2017', 'M-000008', '3112123', 'Ayawaddy MPU', '211221', '', 'renewfees'),
('PY-000012', '04/29/2017', 'M-000008', '3112123', 'Ayawaddy MPU', '20/04/2016', '', 'renewfees'),
('PY-000012', '04/29/2017', 'M-000008', 'asfas', 'Ayawaddy MPU', '211221', '', 'renewfees'),
('PY-000013', '04/29/2017', 'M-000008', '3112123', 'Ayawaddy MPU', '20/04/2016', '', 'renewfees'),
('PY-000014', '04/29/2017', 'M-000008', '3112123', 'Ayawaddy MPU', '211221', '', 'renewfees'),
('PY-000015', '04/29/2017', 'M-000009', '3112123', 'KBZ MPU', '20/04/2017', '', 'registrationfees'),
('PY-000016', '04/29/2017', 'M-000009', '3112123', 'KBZ MPU', '20/04/2016', '', 'renewfees'),
('PY-000017', '04/29/2017', 'M-000009', '3112123', 'KBZ MPU', '20/04/2016', '10000', 'renewfees'),
('PY-000018', '04/29/2017', 'M-000009', '123123', 'Ayawaddy MPU', '20/04/2016', '10000', 'renewfees'),
('PY-000019', '04/29/2017', 'M-000009', '3112123', 'Ayawaddy MPU', '20/04/2016', '10000', 'renewfees'),
('PY-000020', '04/29/2017', 'M-000009', '3112123', 'KBZ MPU', '20/04/2016', '10000', 'renewfees'),
('PY-000021', '04/29/2017', 'M-000009', '3112123', 'Ayawaddy MPU', '20/04/2016', '10000', 'renewfees'),
('PY-000022', '04/29/2017', 'M-000008', '3112123', 'Ayawaddy MPU', '20/04/2016', '10000', 'renewfees'),
('PY-000023', '04/29/2017', 'M-000010', '3112123', 'Ayawaddy MPU', '20/04/2016', '20000', 'registrationfees'),
('PY-000024', '04/29/2017', 'M-000010', '3112123', 'KBZ MPU', '20/04/2016', '50000', 'renewfees'),
('PY-000025', '04/29/2017', 'M-000010', '3112123', 'Ayawaddy MPU', '20/04/2016', '15000', 'renewfees');

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE `publisher` (
  `PublisherID` varchar(50) NOT NULL,
  `PublisherName` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`PublisherID`, `PublisherName`, `Description`) VALUES
('PL-001', 'Penguin', ''),
('PL-002', 'Myint', '');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `PurchaseID` varchar(50) NOT NULL,
  `SupplierID` varchar(50) NOT NULL,
  `PurchaseDate` varchar(50) NOT NULL,
  `TotalAmount` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Numbersofbooks` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`PurchaseID`, `SupplierID`, `PurchaseDate`, `TotalAmount`, `Description`, `Numbersofbooks`, `Status`) VALUES
('PC-000001', 'SU-001', '04/25/2017', '160000', '', '', ''),
('PC-000002', 'SU-001', '04/29/2017', '15992', '', '', ''),
('PC-000003', 'SU-001', '04/29/2017', '1000', '', '', ''),
('PC-000004', 'SU-001', '04/29/2017', '1222', '', '', ''),
('PC-000005', 'SU-001', '04/29/2017', '14664', '', '', ''),
('PC-000006', 'SU-001', '04/29/2017', '2444', '', '', ''),
('PC-000007', 'SU-001', '04/29/2017', '2444', '', '', ''),
('PC-000008', 'SU-001', '04/29/2017', '2444', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `purchasedetail`
--

CREATE TABLE `purchasedetail` (
  `PurchaseID` varchar(50) NOT NULL,
  `BookID` varchar(50) NOT NULL,
  `Quantity` varchar(50) NOT NULL,
  `Price` int(50) NOT NULL,
  `Status` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchasedetail`
--

INSERT INTO `purchasedetail` (`PurchaseID`, `BookID`, `Quantity`, `Price`, `Status`) VALUES
('PC-000001', '', '10', 2000, 0),
('PC-000001', 'B-00002', '10', 2000, 0),
('PC-000001', 'B-00001', '12', 10000, 0),
('PC-000002', 'B-00001', '4', 1999, 0),
('PC-000002', 'B-00002', '4', 1999, 0),
('PC-000003', 'B-00001', '1', 1000, 0),
('PC-000004', 'B-00002', '1', 1222, 0),
('PC-000005', 'B-00001', '12', 1222, 0),
('PC-000006', 'B-00001', '2', 1222, 0),
('PC-000007', 'B-00002', '2', 1222, 0),
('PC-000008', 'B-00002', '1', 1222, 0),
('PC-000008', 'B-00001', '1', 1222, 0);

-- --------------------------------------------------------

--
-- Table structure for table `reserve`
--

CREATE TABLE `reserve` (
  `ReserveID` varchar(50) NOT NULL,
  `MemberID` varchar(50) NOT NULL,
  `ReserveDate` varchar(50) NOT NULL,
  `TotalPoints` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserve`
--

INSERT INTO `reserve` (`ReserveID`, `MemberID`, `ReserveDate`, `TotalPoints`, `Status`) VALUES
('R-000001', 'M-000009', '04/29/2017', '20', 'reserve'),
('R-000002', 'M-000009', '04/29/2017', '80', 'reserve'),
('R-000003', 'M-000009', '04/29/2017', '100', 'reserve'),
('R-000004', 'M-000009', '04/29/2017', '100', 'reserve'),
('R-000005', 'M-000009', '04/29/2017', '100', 'reserve'),
('R-000006', 'M-000009', '04/29/2017', '100', 'reserve'),
('R-000007', 'M-000009', '04/29/2017', '80', 'reserve'),
('R-000008', 'M-000009', '04/29/2017', '60', 'reserve'),
('R-000009', 'M-000009', '04/29/2017', '40', 'reserve'),
('R-000010', 'M-000009', '04/29/2017', '20', 'reserve'),
('R-000011', 'M-000009', '04/29/2017', '100', 'reserve'),
('R-000012', 'M-000010', '04/29/2017', '100', 'reserve');

-- --------------------------------------------------------

--
-- Table structure for table `reservedetail`
--

CREATE TABLE `reservedetail` (
  `ReserveID` varchar(50) NOT NULL,
  `BookID` varchar(50) NOT NULL,
  `availabledate` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservedetail`
--

INSERT INTO `reservedetail` (`ReserveID`, `BookID`, `availabledate`, `status`) VALUES
('R-000001', '21313123', '', 'reservedetail'),
('R-000002', '21312312', '', 'reservedetail'),
('R-000003', '21313123', '', 'reservedetail'),
('R-000004', '21313123', '', 'reservedetail'),
('R-000005', '21313123', '', 'reservedetail'),
('R-000006', '21313123', '', 'reservedetail'),
('R-000007', '21313123', '', 'reservedetail'),
('R-000008', '21313123', '', 'reservedetail'),
('R-000009', '21313123', '', 'reservedetail'),
('R-000010', '21313123', '', 'reservedetail'),
('R-000011', '21313123', '', 'reservedetail'),
('R-000012', 'adsfa', '', 'reservedetail');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `StaffID` varchar(45) NOT NULL,
  `StaffName` varchar(45) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Phone` int(11) NOT NULL,
  `UserName` varchar(45) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `StaffName`, `Address`, `Phone`, `UserName`, `Password`) VALUES
('ST-001', 'Shlbb', 'No 2345', 667788, 'administrator', 'administrator'),
('ST-002', 'dfs', 'dsfd', 0, 'tttttt', 'ttttt');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `SupplierID` varchar(45) NOT NULL,
  `SupplierName` varchar(45) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Phone` int(11) NOT NULL,
  `Email` varchar(45) NOT NULL,
  `Fax` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`SupplierID`, `SupplierName`, `Address`, `Phone`, `Email`, `Fax`) VALUES
('S-001', 'Top Company', 'No(123)', 1245666, 'test@gmail.com', 31231312);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
