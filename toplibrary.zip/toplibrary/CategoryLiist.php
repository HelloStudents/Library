<?php

	   
	
    
   

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>
<div class="container">
	<div class="menu_place">
    	<div class="menu">
        <a href="" class="act" >Home</a>
        </div>
    </div>
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <hr class="palblue_hr" />
    	<div class="l_content">
        	<ul id="sidemenu">
            	<li class="smtitle ">Category</li>
           
            	<li><a href="">Category</a></li>
            
            	<li><a href="">Category</a></li>
            </ul>
        </div>
        <div class="r_content" >
          	<?php
			      $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysql_connect($dbhost, $dbuser);
      mysql_select_db( 'Hipster' );
         
   $sql = "SELECT * FROM category ";
   $result= mysql_query( $sql, $conn );
     echo "<table class=tbl cellpadding=0px >";
	 echo "<tr><th>Actions</th><th>Category ID</th><th>Category Name</th><th>Description</th>";
	 $row=0;
   while(mysql_num_rows($result)>$row)
   {
   
	 echo "<tr>";
	  echo "<td>";
	  echo mysql_result($result ,  $row,0);
	   echo "</td>";
	    echo "<td>";
	  echo mysql_result($result ,  $row,1);
	   echo "</td>";
	    echo "<td>";
	  echo mysql_result($result ,  $row,2);
	   echo "</td>";
	  echo "</tr>";
	  $row++;

   }
    echo "</table>";
   mysql_close($conn);
    
			?>
        </div>
        <div style="clear:left;height:20px;"></div>
    </div>
<div class="menu_place">
    	<div class="menu">
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT ( C ) 2016 | HIPSTER </span>
                </div>
                	<div style="width:50%;float:right;">
                     	<a href="" style="float:right;">Admin Area</a>
                </div>
        </div>
    </div>    
</div>
</body>
</html>
