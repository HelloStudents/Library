<?php
  if($_REQUEST['type']=="Fabric")
  {
	  $t=$_REQUEST['type'];
     echo "
<table  >
             <tr>
               <td colspan=3><h3>Specific Information for $t </h3><hr/></td>
             </tr>
             <tr>
             <td></td> <td></td>
              
             </tr>
             
            <tr>
             <td>Fabric Type</td> <td><input type=text name=fabrictype /></td>
              
             </tr>
              <tr>
             <td>Fabric Description</td> <td><input type=text name=fabricdescription /></td>
              
             </tr>
               <tr>
             <td>Made By</td> <td><input type=text name=madeby /></td>
              
             </tr>
            
          </table>
";
  }
?>