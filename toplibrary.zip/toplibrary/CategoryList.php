<?php
session_start();
$status="Save"; 
$msg="";
$id="";
	include("advance_control.php");
 if(isset($_REQUEST['m']))
   {
	  $msg=$_REQUEST['m'];
   
   }
  
 if(isset($_REQUEST['request']))
   {
	  $status=$_REQUEST['request'];
	
     $id=$_REQUEST['uid'];
   }
   else
   {
   $id= getID("bookcategory","categoryID","C-",3,"C-001");
  // echo "sds".$id;
   }
   if(isset($_REQUEST['btn']))
   {
	   
	   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $mysqli = new mysqli('localhost','root','','top');

 if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}
  $insert_row = $mysqli->query( "INSERT INTO bookcategory VALUES ('".$_REQUEST['categoryID']."','".$_REQUEST['categoryname']."','".$_REQUEST['description']."')");

		if($insert_row)
		{
   			header("Location: CategoryList.php?m=Successfully Save !");
 		}
 		else
 		{
    die('Error : ('. $mysqli->errno .') '. $mysqli->error);
		}
	$mysqli->close();
 
 
       }


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
   <div class="menu_place">
    	<div class="menu">
      <?php include("menudata.php"); ?>
        </div>
    </div>
    	<div class="l_content">
        <!--	<ul id="sidemenu">
            	<li class="smtitle ">Entry</li>
          <li>  <a href="StaffList.php"  >Staff </a></li>
          <li> <a href="CategoryList.php" class="act" >Category </a></li>
         <li>  <a href="SupplierList.php"  >Supplier </a></li>
            	
            </ul>!-->
        </div>
        <div class="r_content" >
        <h3>Category List</h3><hr/>
          <?php
		   if(isset($_REQUEST['msg']))
   {
	 print $_REQUEST['msg'];
   
   }
		    
		  		$mysqli=new mysqli("localhost","root","","top");
				$result=$mysqli->query("SELECT * FROM bookcategory");
				echo "<a href=Category.php class=sp_a>Add New Category</a>";
				 echo "<table class=tbl cellpadding=0px >";
	 echo "<tr><th>Actions</th><th>Category ID</th><th>Category Name</th><th>Description</th>";
	
				while($row=$result->fetch_assoc())
				{
				  print "<tr>";
				  
				    print "<td><a href=Category.php?request=Update&uid=".$row['categoryID']." >Edit</a>&nbsp;&nbsp;<a href=Category.php?did=".$row['categoryID']." >Delete</a></td><td>".$row['categoryID']."</td><td>".$row['categoryname']."</td><td>".$row['description'];
				    print "</tr>";
				}
				echo "</table>";
		  ?>
          
          
        </div>
        <div style="clear:left;height:20px;"></div>
    </div>
    
</div>
</body>
</html>
