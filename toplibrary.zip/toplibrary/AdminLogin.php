<?php

session_start();
	include("advance_control.php");
	$msg="";
 if(isset($_REQUEST['msg']))
   {
	  $msg=$_REQUEST['msg'];
   
   }
  

   if(isset($_REQUEST['btn']))
   {
	  $mysqli=connect();
	 $result = $mysqli->query("SELECT * FROM staff WHERE UserName ='".$_REQUEST['UserName']."' AND Password='".$_REQUEST['Password']."'");
		//row_data= $result->fetch_assoc();
	while($row=$result->fetch_assoc())
	{
		$_SESSION['administrator']=$row["UserName"];
	
		$_SESSION['staff']=$row["StaffID"];
	header("Location: Purchase.php");
	}
      $msg="Invalid User Name and Password !"; 
   }


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>

<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />

    <div class="menu_place">
    	<div class="menu">
   <?php include("menudata.php"); ?>
        </div>
    </div>
        <div style="width:500px;margin:0 auto;margin:0 auto;"  >
            <form action="AdminLogin.php" method="post">
            
            <table class="tform"  style="margin-left:30px;border:#666 thin solid;padding:20px;" cellpadding="5px" align="center">
                <tr>
                    <td colspan="2"><h3>Staff Login</h3><hr class="palblue_hr"/> </td>
                </tr>
                <tr>
                    <td colspan="2"><span class="vc"><?php echo $msg; ?></span></td>
                </tr>
              
                <tr>
                    <td >User Name</td><td><input type="text" name="UserName"  /></td>
                </tr>
             
                
                 
                 <tr>
                    <td >Password</td><td><input type="password" name="Password"  /></td>
                </tr>
                <tr>
                    <td ></td><td><input type="submit" name="btn" value="Sign In" /></td>
                </tr>
                 <tr>
                    <td colspan="2"><hr class="palblue_hr"/>  </td>
                </tr>
            </table>
            </form>
        </div>
        <div style="clear:left;height:20px;"></div>
   <?php include("footer.php"); ?>
</body>
</html>
