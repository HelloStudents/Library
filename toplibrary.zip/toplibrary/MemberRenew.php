<?php
session_start();
$status="Create  Account"; 
$msg="";
$PaymentID="";
$PaymentDate="";
$CardNo="";
$CardType="";

$Email="";
$Password="";
$amsg="";

	include("advance_control.php");

   if(isset($_REQUEST['amsg']))
   {
	  $amsg=$_REQUEST['amsg'];
   
   }
 
     $tmp=$_SESSION["memberinfo"];

   $PaymentID= getID("payment","PaymentID","PY-",6,"PY-000001");
  // echo "sds".$id;

   
   if(isset($_REQUEST['checkout']))
   {
	   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $mysqli = new mysqli('localhost','root','','top');

	// if ($mysqli->connect_error) {
		//die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		//}
	  

	  $insert_row = $mysqli->query( "INSERT INTO payment VALUES ('".$_REQUEST['PaymentID']."','".$_REQUEST['PaymentDate']."','"
	  .$_SESSION["member"]."','".$_REQUEST['cardno']."','".$_REQUEST['cardtype']."','".$_REQUEST['expiredate']."','".$_REQUEST['totalamount']."','renewfees')");
	
			if($insert_row)
			{
			


    $tmp=$_SESSION["memberinfo"];
				$end=date('m/d/Y', strtotime($tmp[4].' + 365 days'));
				 $sql="UPDATE member SET MemberRegistrationDate='".$_REQUEST['PaymentDate']."' , MemberExpiredDate='".$end."',Points='100',status='activate' WHERE MemberID='".$_SESSION["member"]."'";
				
    process($sql);
$tmp=$_SESSION["memberinfo"];
$tmp[4]=$end;
$_SESSION["memberinfo"]=$tmp;
				header("Location: Mylibrary.php?msg=Congratulation Successfully Renew your Account!");
			}
			else
			{
		die('Error : ('. $mysqli->errno .') '. $mysqli->error);
			}
		$mysqli->close();
	  	 }
		
 


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>

<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <div class="menu_place">
    	<div class="menu">
           <?php include("menudata.php"); ?>
        </div>
    </div>
    	<div class="l_content"  style="width:400px;">
        	
           <?php
			if(isset($_SESSION["memberinfo"]))
			{
				
			    $tmp=$_SESSION["memberinfo"];
				echo "<table   style=\"margin-left:20px;border:#666 thin solid;padding:20px;margin-top:20px;\" cellpadding=5px>";
				echo "<tr><td colspan=2 align=center>Member Information<hr class=palblue_hr /></td></tr>";
					echo "<tr style=\"border-bottom:#666 thin solid;\" >";
						echo "<td>Member Name</td><td>:". $tmp[0]."</td>";
					echo "</tr>";
					echo "<tr  style=\"border-bottom:#666 thin solid;\" >";
						echo "<td> Address</td><td>:". $tmp[2]."</td>";
					echo "</tr>";
					echo "<tr style=\"border-bottom:#666 thin solid;\" >";
						echo "<td> Email</td><td>:". $tmp[1]."</td>";
					echo "</tr>";
					echo "<tr style=\"border-bottom:#666 thin solid;\" >";
						echo "<td>Expire Date</td><td>:". $tmp[4]."</td>";
					echo "</tr>";
				echo "</table>";
				
			   
			}
			
			
			?>
        </div>
        <div class="r_content"  style="width:600px; ">
            <form action="MemberRenew.php" method="post">
            
            <table class="tform"  style="margin-left:30px;border:#666 thin solid;padding:20px;" cellpadding="5px" align="center">
                <tr>
                    <td colspan="2"><h3>Member Renew Form</h3><hr class="palblue_hr"/> </td>
                </tr>
                <tr>
                    <td colspan="2"><span class="vc"><?php echo $amsg; ?></span></td>
                </tr>
                <tr>
                    <td ></td><td><input name="PaymentID" type="hidden" value="<?php echo $PaymentID;?>" readonly="readonly" /></td>
                </tr>
                <tr>
                    <td >PaymentDate</td><td><input type="text" name="PaymentDate" value="<?php echo getTodayDate( ); ?>" readonly="readonly" required="required" /></td>
                </tr>
                 <tr>
                    	<td>Card Number:</td>
                        <td><input name="cardno" type="text" value=""  size="40" required="required"/></td>
                    </tr>
                    <tr>
                    	<td>Card Type:</td>
                        <td><select name="cardtype" ><option>Ayawaddy MPU</option><option>KBZ MPU</option></select></td>
                    </tr>
                    <tr>
                    	<td>Expire Date:</td>
                        <td><input name="expiredate" type="text" id="expiredate" value=""  size="40" required="required"/></td>
                    </tr>
                   <tr>
                    	<td>Total Amount(Kyats):</td>
                        <td><input type="text" name="totalamount" id="totalp"  readonly="readonly" value="15000" /></td>
                    </tr>
                <tr>
                    <td ></td><td><input type="submit" name="checkout" value="Check Out" /</td>
                </tr>
                 <tr>
                    <td colspan="2"><hr class="palblue_hr"/>  </td>
                </tr>
            </table>
            </form>
        </div>
        <div style="clear:left;height:20px;"></div>
           <?php include("footer.php"); ?>
</body>
</html>
