<?php
session_start();
$status="Save"; 
$msg="";
$id="";
	include("advance_control.php");
 


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
   <div class="menu_place">
    	<div class="menu">
        <?php include("menudata.php"); ?>
        </div>
    </div>
    	<div class="l_content">
        
        </div>
        <div class="r_content" >
        <h3>Staff List</h3><hr/>
          <?php
		   if(isset($_REQUEST['msg']))
   {
	 print $_REQUEST['msg'];
   
   }
		    
		  		$mysqli=new mysqli("localhost","root","","easyway");
				$result=$mysqli->query("SELECT StaffID,StaffName,Address ,Phone,UserName FROM staff");
				echo "<a href=Staff.php class=sp_a>Add New Staff</a>";
				 echo "<table class=tbl cellpadding=0px >";
	 echo "<tr><th>Actions</th><th>Staff ID</th><th>Staff Name</th><th>Address</th><th>Phone</th><th>UserName</th>";
	
				while($row=$result->fetch_assoc())
				{
				  print "<tr>";
				  
				    print "<td><a href=Staff.php?request=Update&uid=".$row['StaffID']." >Edit</a>&nbsp;&nbsp;<a href=Staff.php?did=".$row['StaffID']." >Delete</a></td><td>".$row['StaffID']."</td><td>".$row['StaffName']."</td><td>".$row['Address']."</td><td>".$row['Phone']."</td><td>".$row['UserName']."</td>";
				    print "</tr>";
				}
				echo "</table>";
		  ?>
          
          
        </div>
        <div style="clear:left;height:20px;"></div>
       </div>
</body>
</html>
