<?php
$query="SELECT * from designtype";
					  
					  
					$mysqli=connect();
						 $result=$mysqli->query($query);
						 $rowcount=mysqli_num_rows( $result);
						 $row=0;
						 if($rowcount>0)
						{	
						echo   "<li><a href=uproduct.php>All</a></li>";

							 while($row=$result->fetch_array())
							 {
							echo   "<li><a href=uproduct.php?catid=".$row["designtypeid"]." >".$row["designtype"]."</a></li>";
							 }
						 
						 
						}
		

?>