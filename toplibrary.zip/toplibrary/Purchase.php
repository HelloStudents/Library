<?php
session_start();



	include("advance_control.php");
$message = "";
$name="";
$id="";
if (isset($_POST['b_save']))
	{
		 
		$tmp=array($_POST['purchaseid'],$_POST['suppliername'],$_POST['pdate'],$_POST['total'],"","","");
       if(isset($_SESSION['sitem']))
	  {
	    saveData($tmp,"purchase");
$bid=$_POST['purchaseid'];
      for($z=0;$z<count( $_SESSION['sitem']);$z++)
		 {
			
		     $data=array($bid ,$_SESSION['sitem'][$z][0],$_SESSION['sitem'][$z][2],$_SESSION['sitem'][$z][3],"");
			// echo "t".$_SESSION['bitem'][$z][0];
		   $qty= getSelectOneColumnValue(" book ","BookID",$_SESSION['sitem'][$z][0],"Qty");
		     $qty=  $qty+ $_SESSION['sitem'][$z][2];
			   $copy= getSelectOneColumnValue(" book ","BookID",$_SESSION['sitem'][$z][0],"NumberofCopies");
		     $copy=  $copy+ $_SESSION['sitem'][$z][2];
			 $aql="UPDATE book SET qty='".$qty."',NumberofCopies='".  $copy."' WHERE BookID='".$_SESSION['sitem'][$z][0]."'";
			 process($aql);
			 
	
	
			 saveData($data,"purchasedetail");
			 
	  
		 }
		 unset($_SESSION['sitem']);
		$message = "Purchase Information was successfully saved!";    
	  }
	  else
	  {
	   $message = "You have not add any putrchase phone!";    
	  }
	}
	$total=0;
      if(isset($_SESSION['sitem']))
	  {
		
	     for($z=0;$z<count( $_SESSION['sitem']);$z++)
		 { 
		 $total=$total+($_SESSION['sitem'][$z][2]*$_SESSION['sitem'][$z][3]);
		 }
	  }

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />
<script type="text/javascript" src="jquery-1.9.1.js"></script>

<script type="text/javascript">
$(document).ready(function(e) 
 {
	
     $('#itemid').change(function()
      {
		 
		     var type=$(this).val();
			// var area=$('#farea');
			
			
			   $.ajax({
			      
			   type: 'POST',
			   url: 'purchaseitem.php',
			   data: 'type='+type,
			   success: function(msg){
				
				 var d=msg.split("&");
				 $('#ItemID').val(d[0]);
		  		 $('#itmname').val(d[1]);
				 	  $('#sqty').html("Current Qty:"+d[2]+" , Current Selling Price:"+d[3]+" , Product Type :"+d[4]);
			
				
			   }
			   
			   });
			  }); 
			  	 $('#btnadd').click(function()
            {
				if($('#ItemID').val()=="")
				{
				    alert("Please Click on the item");
				}
				else if($('#Qty').val()==""||$('#Qty').val()<1)
				{
				    alert("Please Enter valid Qty(Order Qty must be at least 1!)");
				}
				else if($('#Price').val()==""||($('#Price').val()<500))
				{
				 		    alert("Please Enter valid Price(Price  must be at least 500!)");
				}
				else
				{
				  
				  //alert("d");
				  $.ajax({
			      
			   type: 'POST',
			   url: 'purchaseitem.php',
			   data: 'ItemID='+$('#ItemID').val()+"&act=add&qty="+$('#Qty').val()+"&bbtype="+ $('#ItemID').val()+"&price="+$('#Price').val()+"&salerate="+$('#salerate').val(),
			   success: function(msg){
				
				$('#bitmarea').html(msg);
				
				
			      }
				  });
				    $.ajax({
			      
			   type: 'POST',
			   url: 'purchaseitem.php',
			   data:"testact=total",
			   success: function(gg){
				
				$('#total').val(gg);
				
			      }
				  });
				}
			});
 });
</script>
</head>

<body>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
<div class="menu_place">
    	<div class="menu">
     <?php include("menudata.php"); ?>
        </div>
    </div>
    	
        <div class="r_content" width="1000px" >
         
        
    
     <form action="purchase.php" method="POST">

              <table class="tform" >
                   <tr>
                   		<td colspan="2" align="center">
                        
                        <h3>Purchase Form</h3><hr style="margin-bottom:20px;"/>
                        </td>
                   	</tr>
                    <tr>
                    	<td colspan="2">
                          <?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg'];
				 }
				 else
				 {
				   echo $message;
				 }
				?>
                        </td>
                    </tr>
  <tr>
    
    	<td> Purchase ID </td>
        
        <td> <input name="purchaseid" type="text" id="purchaseid" value="<?php echo getID("purchase","PurchaseID","PC-",6,"PC-000001") ?>" readonly="readonly" />  </td>
    
    </tr>
    
     <tr>
    
    	<td> Purchase Date </td>
        
        <td> <input name="pdate" type="text" id="pdate" value="<?php echo getTodayDate(); ?>" readonly="readonly" /></td>
    
    </tr>
    
    
    <tr>
    
    	<td>Supplier Name</td>
        
        <td><?php convertToidandnameCombo("supplier","SupplierID","SupplierName","suppliername"); ?> </td>
    
    </tr>
    
    
    <tr>
    
    	<td> Total Amount</td>
        
        <td> <input name="total" type="text"  id="total" value="<?php echo $total; ?>" readonly="readonly" /> </td>
        
      
    
    </tr>
     
    
   
    
                    <tr>
                    	<td>&nbsp;</td>
                        <td align="center"><input name="b_save" type="submit" class="buton" value="Save"/></td>
                    </tr>
                   <tr>
    
    	<td colspan="2" >
       

        	
        	
        </td>
        
        
    
    </tr>
                </table>
                 </form>
                <table class="tform"  width="600px">
                        			  <tr>
                            			<td valign="top">
                                        Book ID<br/>
                           				 
                                          <?php
                                      	echo "<div id=tt>";    	
											  printCombowithscript("SELECT * FROM book","name=itemid  id=itemid " ,"BookName","BookID");
											echo "</div >";
										  ?>
                                              
                           			 </td>
                          			  <td valign="top">
                                                            <table>
                                                         <tr>
                                                           <td colspan="3"><h3>Purchase Book Information</h3>
                                                             <hr/></td>
                                                         </tr>
                                                         <tr>
                                                         <td>Book ID</td> <td><input name="ItemID" type="text" class="green" id="ItemID" value="" readonly="readonly" /></td>
                                                          
                                                         </tr>
                                                          <tr>
                                                         <td>Book Name</td> <td><input name="Itemname" type="text" class="green" id="itmname" readonly="readonly"  /></td>
                                                          
                                                         </tr>
                                                         
                                                         
                                                          <tr>
                                                         <td>Qty</td> <td><input type="text" id="Qty" name="Qty"  /></td>
                                                          
                                                         </tr>
                                                          <tr>
                                                         <td>Price</td> <td><input type="text" id="Price"  name="Price"  /></td>

                                                          
                                                         </tr>
                                                         <tr>
                                                           <td colspan="2" align="right"><input type="submit" class="buton" name="btnaddd" id="btnadd" value="Add Data" />                  <hr/>
                                                           
                                                            </td>
                                                         </tr>
                                                         
                                                      </table>	
                         			   </td>
                         			
                                     	<td valign="top">
                                        <br/>
                                        	<div id="bitmarea">
                                        
                                        <?php
										
										if(isset($_SESSION['sitem']))
	  {
		  $t=count($_SESSION['sitem']);
	    
	    echo "<table border=1>
	      <th>Book ID</th><th>Book Name</th><th>Qty</th><th>Price</th>";
	     for($z=0;$z<count( $_SESSION['sitem']);$z++)
		 {
		   
		  echo "<tr>
		  	<td>". $_SESSION['sitem'][$z][0]."</td>
			 	<td>". $_SESSION['sitem'][$z][1]."</td>
				 	<td>". $_SESSION['sitem'][$z][2]."</td>
					<td>". $_SESSION['sitem'][$z][3]."</td>
		  </tr>";
	  
		 }
		    echo "</table>";
		
	  }
										
										?>
                                        
                                        </div>
                                        </td>
                                     </tr>
                       			 </table>
        
        </td>
        
        
        </tr>
        
       
    
    </table>
    
    
    </form>
    
    

    

        </div>
        <div style="clear:left;height:20px;"></div>
    </div>
    
</div>
</body>
</html>
