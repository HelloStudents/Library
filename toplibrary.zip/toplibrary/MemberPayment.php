<?php
session_start();
$status="Create  Account"; 
$msg="";
$PaymentID="";
$PaymentDate="";
$CardNo="";
$CardType="";

$Email="";
$Password="";
$amsg="";

	include("advance_control.php");

   if(isset($_REQUEST['amsg']))
   {
	  $amsg=$_REQUEST['amsg'];
   
   }
   if(!isset($_SESSION["stillnew"])&&!isset($_SESSION["member"]))
   {
	// header("location:Member.php?msg=Need to make registration first !");
   
   }
  
  

   $PaymentID= getID("payment","PaymentID","PY-",6,"PY-000001");
  // echo "sds".$id;

   
   if(isset($_REQUEST['checkout']))
   {
	   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $mysqli = new mysqli('localhost','root','','top');

	// if ($mysqli->connect_error) {
		//die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		//}
	  

	  $insert_row = $mysqli->query( "INSERT INTO payment VALUES ('".$_REQUEST['PaymentID']."','".$_REQUEST['PaymentDate']."','"
	  .$_SESSION['stillnew']."','".$_REQUEST['cardno']."','".$_REQUEST['cardtype']."','".$_REQUEST['expiredate']."','".$_REQUEST['totalamount']."','registrationfees')");
	
			if($insert_row)
			{
				$end=date('m/d/Y', strtotime($_REQUEST['PaymentDate'].' + 365 days'));
				 $sql="UPDATE member SET MemberRegistrationDate='".$_REQUEST['PaymentDate']."' , MemberExpiredDate='".$end."',Points='100',status='activate' WHERE MemberID='".$_SESSION["stillnew"]."'";
				
    process($sql);
unset($_SESSION["stillnew"]);
unset($_SESSION["stillnewinfo"]);
				header("Location: Home.php?msg=Congratulation You can login Now!");
			}
			else
			{
		die('Error : ('. $mysqli->errno .') '. $mysqli->error);
			}
		$mysqli->close();
	  	 }
		
 


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>

<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <div class="menu_place">
    	<div class="menu">
           <?php include("menudata.php"); ?>
        </div>
    </div>
    	<div class="l_content"  style="width:400px;">
        	
            <?php
			if(isset($_SESSION["stillnewinfo"]))
			{
				echo "The following is your member information!";
			    $tmp=$_SESSION["stillnewinfo"];
				echo "<table>";
					echo "<tr>";
						echo "<td>Member Name</td><td>". $tmp[1]."</td>";
					echo "</tr>";
					echo "<tr>";
						echo "<td>Member Address</td><td>". $tmp[2]."</td>";
					echo "</tr>";
					echo "<tr>";
						echo "<td>Member Email</td><td>". $tmp[3]."</td>";
					echo "</tr>";
				echo "</table>";
			   
			}
			
			
			?>
        </div>
        <div class="r_content"  style="width:600px; ">
            <form action="MemberPayment.php" method="post">
            
            <table class="tform"  style="margin-left:30px;border:#666 thin solid;padding:20px;" cellpadding="5px" align="center">
                <tr>
                    <td colspan="2"><h3>Member Payment</h3><hr class="palblue_hr"/> </td>
                </tr>
                <tr>
                    <td colspan="2"><span class="vc"><?php echo $amsg; ?></span></td>
                </tr>
                <tr>
                    <td ></td><td><input name="PaymentID" type="hidden" value="<?php echo $PaymentID;?>" readonly="readonly" /></td>
                </tr>
                <tr>
                    <td >PaymentDate</td><td><input type="text" name="PaymentDate" value="<?php echo getTodayDate( ); ?>" readonly="readonly" required="required" /></td>
                </tr>
                 <tr>
                    	<td>Card Number:</td>
                        <td><input name="cardno" type="text" value=""  size="40" required="required"/></td>
                    </tr>
                    <tr>
                    	<td>Card Type:</td>
                        <td><select name="cardtype" ><option>Ayawaddy MPU</option><option>KBZ MPU</option></select></td>
                    </tr>
                    <tr>
                    	<td>Expire Date:</td>
                        <td><input name="expiredate" type="text" id="expiredate" value=""  size="40" required="required"/></td>
                    </tr>
                    <tr>
                    	<td>Total Amount:(Kyats)</td>
                        <td><input type="text" name="totalamount" id="totalp"  readonly="readonly" value="20000" /></td>
                    </tr>
                <tr>
                    <td ></td><td><input type="submit" name="checkout" value="Check Out" /</td>
                </tr>
                 <tr>
                    <td colspan="2"><hr class="palblue_hr"/>  </td>
                </tr>
            </table>
            </form>
        </div>
        <div style="clear:left;height:20px;"></div>
           <?php include("footer.php"); ?>
</body>
</html>
