<?php
session_start();
include ("advance_control.php");
//include("control.php");
//mysql_connect("localhost","root","");
//mysql_select_db("starmobilephone");
if(isset($_GET["btnremove"]))
{
	
 $query = $_SERVER['QUERY_STRING'];
$vars = array();

foreach (explode('&', $query) as $pair) {
    list($key, $value) = explode('=', $pair);
    if($key=="remove")
	{
	  	unset($_SESSION['itm'][$value]);
		$_SESSION['itm']=array_values($_SESSION['itm']);
		
     if(count($_SESSION['itm'])==0)
	 {
		 unset($_SESSION['itm']);
	   header("Location:home.php");
	 }
	 
	}
}	

	 
	 
}


	//   echo $_POST['ItemID'],$_POST['Itemname'],$_POST['Qty'],$_POST['Price'],"0",$_POST['Description'],$_POST['itype'],$destination;


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>
<div class="container">
	<div class="menu_place">
    	<div class="menu">
          <?php include("menudata.php"); ?>
        </div>
    </div>
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <hr class="palblue_hr" />
    	<div class="l_content">
        	<ul id="sidemenu">
            	<li class="smtitle ">Category</li>
           <li><a href="">Clothes</a></li>
           
            	<li><a href="">Shoes</a></li>
            
            	<li><a href="">Bag</a></li>
                <li><a href="">Accessories</a></li>
            </ul>
        </div>
        <div class="r_content" >
            <form action="myitem.php"  method="get"/>
<?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg'];
				 }
				?>

              <p>
        <?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg'];
				 }
				?>
      </p>
     <?php
	 if(isset($_SESSION['itm']))
	 {
	 //  $itmdata=$_SESSION['itm'];
	 echo "<table border=1 >";
	 
	    echo "<th>Product No</th><th>Product Name</th><th>Qty</th><th>Price</th><th>Select</th>";
	   for($i=0;$i<count($_SESSION['itm']);$i++)
	   {
         

		  
		  echo "<tr>";
		echo "<td>";
			   echo $_SESSION['itm'][$i][0];
			     echo "</td>";
		echo "<td>";
			   echo $_SESSION['itm'][$i][1];
			     echo "</td>";
				 echo "<td>";
			   echo $_SESSION['itm'][$i][2];
			     echo "</td>";
				 echo "<td>";
			   echo $_SESSION['itm'][$i][3];
			     echo "</td>";
		   echo "<td align=center><input type=checkbox name=remove value=".$i."> </td>";
	     echo "</tr>";
			  
	   }
	   echo "<tr ><td colspan=5 align=right><input type=submit name=btnremove	 value=Remove Items /> </td></tr>";
	    echo "</table>";
	 
}
	 else
	 {
		 
        header("location:Home.php?msg=You haven't add any item!");
	 
	 }

	 ?> 
    
      

  </form>
        </div>
        <div style="clear:left;height:20px;"></div>
    </div>
<div class="menu_place">
    	<div class="menu">
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT ( C ) 2016 | HIPSTER </span>
                </div>
                	<div style="width:50%;float:right;">
                     	
                </div>
        </div>
    </div>    
</div>
</body>
</html>
