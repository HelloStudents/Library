<?php
session_start();
include ("advance_control.php");
$total=0;
  
  $startTimeStamp = strtotime($_SESSION['travel'][0]);
$endTimeStamp = strtotime($_SESSION['travel'][2]);

$timeDiff = abs($endTimeStamp - $startTimeStamp);

$numberDays = $timeDiff/86400;  // 86400 seconds in one day

// and you might want to convert to integer
$numberDays = intval($numberDays)+1;

	 if(isset($_SESSION['car']))
	 {
		
		for($i=0;$i<count($_SESSION['car']);$i++)
		 {
		
			$total=$total+($_SESSION['car'][$i][2]*$numberDays);
		 }
	 }
	 if(isset($_SESSION['itm']))
	 {
		 for($i=0;$i<count($_SESSION['itm']);$i++)
		 {
		
			$total=$total+($numberDays*(8 *	$_SESSION['itm'][$i][3]));
		 }
	 }
	 echo $total;
 
 
?>