<?php
session_start();
include("advance_control.php");


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="jquery.datepick.js"></script>
<script type="text/javascript">
$(function() {
	$('#popupDatepicker').datepick();
$('#popupDatepicker1').datepick();
});
</script>
    <style type="text/css">
@import "flora.datepick.css";
</style>
    
</head>
<body>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <div class="menu_place">
    	<div class="menu">
       <?php include("menudata.php"); ?>
        </div>
    </div>
    	
        <div class="r_content" style="width:750px;" >
            <?php
                 if(isset($_GET['msg']))
				 {
				    echo $_GET['msg'];
				 }
				?>
  <table class="tform"  style="margin-left:30px;border:#666 thin solid;padding:20px;margin-bottom:20px;" cellpadding="5px" align="center">
  <tr>
  	<td colspan="2">
  
    </td>
  </tr>
  <tr>
    <td valign="top">
   
     
     <form name="form1" action="searchandreport.php" method="post">
            <table>
<tr>
<td colspan="2">Search & Report <hr/></td>
</tr>
<tr>
<td>

</td>
</tr>
<tr>
<td>Choose Type</td><td><select name="rtype"><option>Monthly Income fees</option>
<option>Borrow Book Report</option>
</select></td>
</tr>
<tr>
<td>From Date</td><td><input type="text" name="from" value="" id="popupDatepicker" />(Example Month/Day/year=1/1/2014)</td>
</tr>
<tr>
<td>To Date</td><td><input type="text" name="to" value="" id="popupDatepicker1" />(Example Month/Day/year=1/1/2014)</td>
</tr>
<tr>
<td align="center"><input name="btn" type="submit" class="btn" value="Search" /></td>
</tr>

</table>
      </form>
      </td>
      </tr>
      </table>
             <?php
if(isset($_POST['btn']))
{
	if($_POST['rtype']=="Monthly Income fees")
    {
		
		$column=array("PaymentID","Member Name","Address","Phone","Email" ,"Total");
		$query="SELECT p.PaymentID ,m.MemberName,m.Address,m.Phone,m.Email,p.totalamount
FROM payment AS p ,member AS m
WHERE p.MemberID= m.MemberID AND p.PaymentDate BETWEEN '".$_POST['from']."' AND  '".$_POST['to']."'";

	$column_name=array("PaymentID","MemberName", "Address", "Phone", "Email","totalamount");
printTable($query,count($column),$column,$column_name);
$_SESSION['column']=$column;
$_SESSION['column_name']=$column_name;	
		$_SESSION['status']="Monthly MemberRegistration Income";
$_SESSION['sql_result']=$query;
		if(isset($_SESSION['sql_result']))
{
    echo "<a href=report.php  target=_blank>Generate Report</a>";
}

	}

	else if($_POST['rtype']=="Borrow Book Report")
    {
		
		$column=array("Borrow ID","Member ID","Member Name","Book ID" ,"Book Name","Borrow Date","Return Date");
		$query="SELECT DISTINCT  bd.BorrowID,m.MemberID,m.MemberName,bk.BookID ,bk.BookName,bd.BorrowDate,bd.ReturnDate FROM borrow AS b,member AS m ,borrowdetail AS bd ,book as bk WHERE b.MemberID=m.MemberID AND b.BorrowID=bd.BorrowID  AND  bd.BookID=bk.BookID AND bd.Status='borrow' AND b.BorrowDate BETWEEN '".$_POST['from']."' AND  '".$_POST['to']."'";

	$column_name=array("BorrowID", "MemberID", "MemberName", "BookID", "BookName","BorrowDate","ReturnDate" );
printTable($query,count($column),$column,$column_name);
$_SESSION['column']=$column;
$_SESSION['column_name']=$column_name;	
		$_SESSION['status']="Borrow Book Report";
$_SESSION['sql_result']=$query;
		if(isset($_SESSION['sql_result']))
{
    echo "<a href=report.php  target=_blank>Generate Report</a>";
}

	}
	
	

}
?>
    
   </div>
        <div style="clear:left;height:20px;"></div>
  
   
</div>
</body>

</html>
