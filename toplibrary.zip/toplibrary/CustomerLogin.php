<?php

session_start();
	include("advance_control.php");
	$msg="";
 if(isset($_REQUEST['msg']))
   {
	  $msg=$_REQUEST['msg'];
   
   }
  
 if(isset($_REQUEST['request']))
   {
	  $status=$_REQUEST['request'];
	
     $SupplierID=$_REQUEST['uid'];
	$mysqli=connect();
	 $result = $mysqli->query("SELECT * FROM supplier WHERE SupplierID ='".$_REQUEST['uid']."'");
		$row_data= $result->fetch_assoc();
	 $Address=$row_data['Address'];
	 $Phone=$row_data['Phone'];
 	$Email=$row_data['Email'];
		$Fax=$row_data['Fax'];

   }
   else
   {
 //  $CustomerID= getID("customer","CustomerID","CT-",6,"CT-000001");
  // echo "sds".$id;
   }
 


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
    <div class="menu_place">
    	<div class="menu">
       <?php include("menudata.php"); ?>

        </div>
    </div>
    	<div class="l_content">
        	<ul id="sidemenu">
            	<li class="smtitle ">Category</li>
             
              <?php include("sidemenu.php"); ?>
            </ul>
        </div>
        <div class="r_content" >
           
        </div>
        <div style="clear:left;height:20px;"></div>
        <div class="menu_place">
    	<div class="menu">
       			<div style="width:50%;float:left;">
                     <span style="display:block;height:45px;line-height:45px;">COPY RIGHT ( C ) 2016 | HIPSTER </span>
                </div>
                	<div style="width:50%;float:right;">
                     	<a href="" style="float:right;">Admin Area</a>
                </div>
        </div>
    </div>
    </div>
    
</div>
</body>
</html>
