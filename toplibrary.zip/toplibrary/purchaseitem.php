<?php
session_start();
include("advance_control.php");

if(isset($_REQUEST['type']))
  {
	  $t=$_REQUEST['type'];
	  $result=search("SELECT * FROM book WHERE BookID='".$_REQUEST['type']."'");
	   $row= $result->fetch_assoc();
	  
	  echo $row["BookID"]."&".$row["BookName"]."&".$row["Qty"];
  }
  if(isset($_REQUEST['testact']))
  {
    	$total=0;
      if(isset($_SESSION['sitem']))
	  {
		
	     for($z=0;$z<count( $_SESSION['sitem']);$z++)
		 { 
		 $total=$total+($_SESSION['sitem'][$z][2]*$_SESSION['sitem'][$z][3]);
		 }
	  }
	  echo $total;
  }
   if(isset($_REQUEST['act']))
  {
	   if($_REQUEST['act']=="add")
     {
	 // $t=$_REQUEST['type'];
	  $result=search("SELECT * FROM book WHERE BookID='".$_REQUEST['bbtype']."'");
//	unset($_SESSION['bitem']);
$row=$result->fetch_assoc();
	  if(isset($_SESSION['sitem']))
	  {
		  $t=count($_SESSION['sitem']);
		  $b=true;
		  for($i=0;$i<count( $_SESSION['sitem']);$i++)
		  {
		        if($_SESSION['sitem'][$i][0]==$_REQUEST['bbtype'])
				{
				  $_SESSION['sitem'][$i][2]=$_REQUEST['qty'];
	    $_SESSION['sitem'][$i][3]=$_REQUEST['price'];
		  $b=false;
				}
		  }
		  if($b==true)
		  {
	     $_SESSION['sitem'][$t][0]=$row["BookID"];
	   $_SESSION['sitem'][$t][1]=$row["BookName"];
	   $_SESSION['sitem'][$t][2]=$_REQUEST['qty'];
	    $_SESSION['sitem'][$t][3]=$_REQUEST['price'];
		  }
	    echo "<table border=1>
	      <th>Book ID</th><th>Book Name</th><th>Qty</th><th>Price</th>";
	     for($z=0;$z<count( $_SESSION['sitem']);$z++)
		 {
		   
		  echo "<tr>
		  	<td>". $_SESSION['sitem'][$z][0]."</td>
			 	<td>". $_SESSION['sitem'][$z][1]."</td>
				 	<td>". $_SESSION['sitem'][$z][2]."</td>
						<td>". $_SESSION['sitem'][$z][3]."</td>
					
		  </tr>";
	  
		 }
		    echo "</table>";
		
	  }
	  else
	  {
		 
	   $_SESSION['sitem'][0][0]=$row["BookID"];
	   $_SESSION['sitem'][0][1]=$row["BookName"];
	   $_SESSION['sitem'][0][2]=$_REQUEST['qty'];
	    $_SESSION['sitem'][0][3]=$_REQUEST['price'];
		
	   echo "<table border=1>
	      <th>Book ID</th><th>Book Name</th><th>Qty</th><th>Price</th>
		  <tr>
		  	<td>".$row["BookID"]."</td>
			 	<td>".$row["BookName"]."</td>
				 	<td>".$_REQUEST['qty']."</td>
					<td>".$_REQUEST['price']."</td>
					
		  </tr>
	     </table>";
	   
	  }
	 }
  }

?>