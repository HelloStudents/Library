<?php
session_start();
$status="Save"; 
$msg="";
$id="";
	include("advance_control.php");
 


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="template.css" rel="stylesheet" />

</head>

<body>
<div class="container">
	
    <div class="mcontent">
    <img src="img/logo.fw.png" />
   <div class="menu_place">
    	<div class="menu">
     <?php include("menudata.php"); ?>
        </div>
    </div>
    	
        <div class="r_content" >
        <h3>Book List</h3><hr/>
          <?php
		   if(isset($_REQUEST['msg']))
   {
	 print $_REQUEST['msg'];
   
   }
		    
		  		$mysqli=new mysqli("localhost","root","","top");
				$result=$mysqli->query("SELECT * FROM book");
				echo "<a href=BookRegistration.php class=sp_a>Add New Book</a>";
				 echo "<table class=tbl cellpadding=0px >";
	 echo "<tr><th>Book ID</th><th>Book Name</th><th>Overview</th><th>Qty</th><th>NumberofCopies</th><th>ISBN</th>";
	
				while($row=$result->fetch_assoc())
				{
				  print "<tr>";
				  
				    print  "<td>".$row['BookID']."</td><td>".$row['BookName']."</td><td>".$row['BookOverview']."</td><td>".$row['NumberofCopies']."</td><td>".$row['ISBNNumber']."</td>";
				    print "</tr>";
				}
				echo "</table>";
		  ?>
          
          
        </div>
        <div style="clear:left;height:20px;"></div>
    </div>
    
</div>
</body>
</html>
